import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Calendar - Capella Pro',
  description: 'Manage your schedule with AI-powered daily planning, recurring events, and multi-timezone support.',
};

export default function CalendarLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
