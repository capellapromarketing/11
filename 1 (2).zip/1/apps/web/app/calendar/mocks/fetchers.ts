"use client";

import { DateTime } from 'luxon';
import type { 
  CalendarEvent, 
  Calendar, 
  Task, 
  ParsedEvent, 
  DailyPlan, 
  SuggestedEvent 
} from '../types/calendar.types';
import mockData from '../mock-data/calendar.mock.json';

const simulateDelay = (ms: number = 300) => 
  new Promise<void>((resolve) => setTimeout(resolve, ms));

export async function fetchCalendars(): Promise<Calendar[]> {
  await simulateDelay(200);
  return mockData.calendars as Calendar[];
}

export async function fetchEvents(): Promise<CalendarEvent[]> {
  await simulateDelay(300);
  return mockData.events as CalendarEvent[];
}

export async function fetchTasks(): Promise<Task[]> {
  await simulateDelay(200);
  return mockData.tasks.map((task: Record<string, unknown>) => ({
    id: task.id as string,
    title: task.title as string,
    dueDate: task.dueDate as string | undefined,
    priority: task.priority as 'low' | 'medium' | 'high',
    isCompleted: (task.isCompleted ?? task.completed ?? false) as boolean,
    estimatedMinutes: task.estimatedMinutes as number | undefined,
  }));
}

export async function createEvent(event: CalendarEvent): Promise<CalendarEvent> {
  await simulateDelay(400);
  return event;
}

export async function updateEvent(
  eventId: string, 
  updates: Partial<CalendarEvent>
): Promise<CalendarEvent> {
  await simulateDelay(300);
  const existingEvent = mockData.events.find((e) => e.id === eventId);
  if (!existingEvent) {
    throw new Error(`Event with id ${eventId} not found`);
  }
  return { ...existingEvent, ...updates } as CalendarEvent;
}

export async function deleteEvent(eventId: string): Promise<void> {
  await simulateDelay(300);
}

export async function parseNaturalLanguageEvent(input: string): Promise<ParsedEvent> {
  await simulateDelay(500);
  
  const now = DateTime.now();
  const lowerInput = input.toLowerCase();
  
  let title = input;
  let startTime: string | undefined;
  let endTime: string | undefined;
  let isAllDay = false;
  let location: string | undefined;
  
  const timePatterns = [
    { pattern: /at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i, handler: (match: RegExpMatchArray) => {
      let hour = parseInt(match[1]);
      const minute = match[2] ? parseInt(match[2]) : 0;
      const meridiem = match[3]?.toLowerCase();
      
      if (meridiem === 'pm' && hour < 12) hour += 12;
      if (meridiem === 'am' && hour === 12) hour = 0;
      
      const start = now.set({ hour, minute, second: 0, millisecond: 0 });
      const end = start.plus({ hours: 1 });
      
      return { startTime: start.toISO(), endTime: end.toISO() };
    }},
    { pattern: /from (\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*(?:to|-)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i, handler: (match: RegExpMatchArray) => {
      let startHour = parseInt(match[1]);
      const startMinute = match[2] ? parseInt(match[2]) : 0;
      const startMeridiem = match[3]?.toLowerCase();
      
      let endHour = parseInt(match[4]);
      const endMinute = match[5] ? parseInt(match[5]) : 0;
      const endMeridiem = match[6]?.toLowerCase();
      
      if (startMeridiem === 'pm' && startHour < 12) startHour += 12;
      if (startMeridiem === 'am' && startHour === 12) startHour = 0;
      if (endMeridiem === 'pm' && endHour < 12) endHour += 12;
      if (endMeridiem === 'am' && endHour === 12) endHour = 0;
      
      const start = now.set({ hour: startHour, minute: startMinute, second: 0, millisecond: 0 });
      const end = now.set({ hour: endHour, minute: endMinute, second: 0, millisecond: 0 });
      
      return { startTime: start.toISO(), endTime: end.toISO() };
    }},
  ];
  
  for (const { pattern, handler } of timePatterns) {
    const match = input.match(pattern);
    if (match) {
      const times = handler(match);
      startTime = times.startTime ?? undefined;
      endTime = times.endTime ?? undefined;
      title = input.replace(pattern, '').trim();
      break;
    }
  }
  
  const datePatterns = [
    { pattern: /\btomorrow\b/i, handler: () => now.plus({ days: 1 }) },
    { pattern: /\btoday\b/i, handler: () => now },
    { pattern: /\bnext week\b/i, handler: () => now.plus({ weeks: 1 }) },
    { pattern: /\bmonday\b/i, handler: () => now.set({ weekday: 1 }).plus({ weeks: now.weekday > 1 ? 1 : 0 }) },
    { pattern: /\btuesday\b/i, handler: () => now.set({ weekday: 2 }).plus({ weeks: now.weekday > 2 ? 1 : 0 }) },
    { pattern: /\bwednesday\b/i, handler: () => now.set({ weekday: 3 }).plus({ weeks: now.weekday > 3 ? 1 : 0 }) },
    { pattern: /\bthursday\b/i, handler: () => now.set({ weekday: 4 }).plus({ weeks: now.weekday > 4 ? 1 : 0 }) },
    { pattern: /\bfriday\b/i, handler: () => now.set({ weekday: 5 }).plus({ weeks: now.weekday > 5 ? 1 : 0 }) },
  ];
  
  for (const { pattern, handler } of datePatterns) {
    if (pattern.test(input)) {
      const targetDate = handler();
      if (startTime) {
        const parsed = DateTime.fromISO(startTime);
        startTime = targetDate.set({ hour: parsed.hour, minute: parsed.minute }).toISO() ?? undefined;
        if (endTime) {
          const parsedEnd = DateTime.fromISO(endTime);
          endTime = targetDate.set({ hour: parsedEnd.hour, minute: parsedEnd.minute }).toISO() ?? undefined;
        }
      } else {
        startTime = targetDate.set({ hour: 9, minute: 0 }).toISO() ?? undefined;
        endTime = targetDate.set({ hour: 10, minute: 0 }).toISO() ?? undefined;
      }
      title = title.replace(pattern, '').trim();
      break;
    }
  }
  
  const locationPattern = /\bat\s+(.+?)(?:\s+(?:at|from|tomorrow|today|next|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|\s*$)/i;
  const locationMatch = input.match(locationPattern);
  if (locationMatch && !locationMatch[1].match(/^\d{1,2}(?::\d{2})?\s*(?:am|pm)?$/i)) {
    location = locationMatch[1].trim();
    title = title.replace(locationPattern, '').trim();
  }
  
  if (lowerInput.includes('all day') || lowerInput.includes('all-day')) {
    isAllDay = true;
    title = title.replace(/all[- ]?day/i, '').trim();
    if (startTime) {
      const parsed = DateTime.fromISO(startTime);
      startTime = parsed.startOf('day').toISO() ?? undefined;
      endTime = parsed.endOf('day').toISO() ?? undefined;
    }
  }
  
  title = title.replace(/\s+/g, ' ').trim();
  if (title.startsWith('Meeting with')) {
  } else if (!title) {
    title = 'New Event';
  }
  
  return {
    title,
    startTime,
    endTime,
    isAllDay,
    location,
  };
}

export async function generateDailyPlan(
  userId: string,
  date: DateTime
): Promise<DailyPlan> {
  await simulateDelay(1500);
  
  const suggestions: SuggestedEvent[] = [
    {
      id: 'sug-1',
      title: 'Focus Time',
      startTime: date.set({ hour: 10, minute: 0 }).toISO() || '',
      endTime: date.set({ hour: 12, minute: 0 }).toISO() || '',
      reason: 'Based on your productivity patterns, this is your best time for deep work.',
    },
    {
      id: 'sug-2',
      title: 'Lunch Break',
      startTime: date.set({ hour: 12, minute: 30 }).toISO() || '',
      endTime: date.set({ hour: 13, minute: 30 }).toISO() || '',
      reason: 'Taking regular breaks improves afternoon productivity.',
    },
    {
      id: 'sug-3',
      title: 'Walk & Stretch',
      startTime: date.set({ hour: 15, minute: 0 }).toISO() || '',
      endTime: date.set({ hour: 15, minute: 15 }).toISO() || '',
      reason: 'A short break to stay energized during the afternoon slump.',
    },
  ];
  
  return {
    summary: `You have 4 meetings scheduled for ${date.toFormat('EEEE, MMMM d')}. Consider blocking time for focused work between meetings.`,
    suggestedEvents: suggestions,
    tips: [
      'Your first meeting is at 9 AM. Consider arriving 10 minutes early.',
      'You have a 2-hour gap after lunch - perfect for deep work.',
      'Remember to take short breaks between back-to-back meetings.',
    ],
  };
}
