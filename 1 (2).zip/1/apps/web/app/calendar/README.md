# Capella Pro Calendar V1.5

## Overview

A modern, full-featured calendar application providing comprehensive scheduling capabilities with natural language event creation, drag-and-drop scheduling, recurring events, timezone handling, and AI-powered daily planning suggestions.

## Tech Stack

| Library | Purpose |
|---------|---------|
| Next.js App Router | Framework & routing |
| TypeScript | Type safety |
| Tailwind CSS | Styling |
| Framer Motion | Animations |
| @dnd-kit | Drag and drop |
| Luxon | Date/time handling |
| rrule | Recurring events |
| react-hook-form | Form management |
| Zod | Schema validation |
| @tanstack/react-query | Data fetching |
| Zustand | State management |
| lucide-react | Icons |
| shadcn/ui | UI components |

## Development

**Start dev server:**
```bash
pnpm dev --filter=apps/web
```

**Run tests:**
```bash
pnpm test --filter=apps/web apps/web/app/calendar
```

**Lint:**
```bash
pnpm lint --filter=apps/web
```

**Type check:**
```bash
pnpm typecheck --filter=apps/web
```

## Mock Data

- **Location:** `mock-data/calendar.mock.json`
- **Usage:** Automatic fallback in `useCalendarData` hook when API unavailable
- **Format:**
  ```json
  {
    "calendars": [...],    // Calendar category definitions
    "events": [...],       // Event objects with dates, recurrence, etc.
    "tasks": [...]         // Task items for sidebar
  }
  ```

## Integration Steps

1. Ensure packages/db stubs are available
2. Configure React Query provider in app layout
3. Set up Zustand store hydration
4. Test with mock data first
5. Connect to real API endpoints
6. Run full test suite

## Architecture

```
apps/web/app/calendar/
├── components/     # Presentational UI components
├── hooks/          # Business logic and data fetching
├── lib/            # Utility functions (dates, recurrence)
├── store/          # Zustand state management
├── types/          # TypeScript definitions
├── mocks/          # Mock API fetchers
└── mock-data/      # Development fallback data
```

### Key Components

| Component | Description |
|-----------|-------------|
| CalendarPage | Main orchestrator component |
| CalendarHeader | View switching, navigation, NLP input |
| CalendarSidebar | Mini calendar, calendar list, task list |
| MonthView | Grid view with event pills |
| WeekView | Timeline view with hourly slots |
| DayView | Single day detailed timeline |
| AgendaView | List view of upcoming events |
| CreateEventModal | Event creation/editing form |
| AIPlannerPanel | AI-powered daily planning |

### Hooks

| Hook | Purpose |
|------|---------|
| useCalendarData | Fetches calendar events via React Query |
| useDragEvents | Handles drag-and-drop event scheduling |
| useNLPInput | Natural language event parsing |
| useDailyPlanner | AI planning suggestions |
| useRecurrence | rrule recurrence calculations |

## Features

- **Natural Language Event Creation** - Type "Meeting with John tomorrow at 2pm" to create events
- **Task ↔ Calendar Auto Sync** - Drag tasks to calendar to schedule them
- **Time Blocking / Drag-to-schedule** - Visual drag-and-drop scheduling
- **AI Daily Planner** - Get AI-powered suggestions for your day
- **Recurring Events** - Daily, weekly, monthly recurrence patterns
- **Timezone Handling** - Full timezone support with visual indicators
- **Video-call Links** - Zoom, Google Meet, Teams integration
- **Travel Time Buffers** - Add travel time before events
- **Undo/Redo** - 5-second undo window for all actions

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Cmd/Ctrl + K` | Focus NLP input |
| `N` | Create new event |
| `←/→` | Navigate previous/next |
| `T` | Go to today |
| `1/2/3/4` | Switch views |
| `S` | Toggle sidebar |
| `Esc` | Close modals |
| `Cmd/Ctrl + Z` | Undo |

## Design Tokens

- **Primary Action:** Aquamarine `hsl(174 65% 48%)`
- **Font:** Inter
- **Event Pills:** 24px min-height, 3px left border
- **Modals:** 280-560px width
- **Animations:** 150ms (modals), 250ms (panels)
