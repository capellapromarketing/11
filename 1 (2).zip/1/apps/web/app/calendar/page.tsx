import { CalendarClientProviders } from './components/CalendarClientProviders';
import { CalendarPage } from './components/CalendarPage';

export default function CalendarRoute() {
  return (
    <CalendarClientProviders>
      <CalendarPage />
    </CalendarClientProviders>
  );
}
