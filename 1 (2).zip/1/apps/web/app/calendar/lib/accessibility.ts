"use client";

export const axeConfig = {
  rules: [
    { id: 'color-contrast', enabled: true },
    { id: 'label', enabled: true },
    { id: 'button-name', enabled: true },
    { id: 'link-name', enabled: true },
    { id: 'aria-required-attr', enabled: true },
    { id: 'aria-valid-attr', enabled: true },
    { id: 'aria-roles', enabled: true },
    { id: 'keyboard-navigation', enabled: true },
    { id: 'focus-visible', enabled: true },
  ],
};

export const calendarAccessibilityRules = {
  eventAnnouncement: {
    format: (title: string, time: string) => 
      `Event: ${title} at ${time}`,
  },
  
  dayNavigation: {
    format: (date: string, eventCount: number) =>
      `${date}, ${eventCount} event${eventCount !== 1 ? 's' : ''}`,
  },
  
  dragAnnouncement: {
    start: (title: string) => `Started dragging event: ${title}`,
    over: (title: string, target: string) => `${title} over ${target}`,
    end: (title: string, target: string) => `Dropped ${title} on ${target}`,
    cancel: (title: string) => `Cancelled dragging ${title}`,
  },
  
  viewAnnouncement: {
    month: (month: string, year: number) => `Month view: ${month} ${year}`,
    week: (startDate: string, endDate: string) => `Week view: ${startDate} to ${endDate}`,
    day: (date: string) => `Day view: ${date}`,
    agenda: () => `Agenda view: Upcoming events`,
  },
};

export function announceToScreenReader(message: string): void {
  if (typeof window === 'undefined') return;
  
  const announcement = document.createElement('div');
  announcement.setAttribute('role', 'status');
  announcement.setAttribute('aria-live', 'polite');
  announcement.setAttribute('aria-atomic', 'true');
  announcement.className = 'sr-only';
  announcement.textContent = message;
  
  document.body.appendChild(announcement);
  
  setTimeout(() => {
    document.body.removeChild(announcement);
  }, 1000);
}

export function getEventAriaLabel(
  title: string,
  startTime: string,
  endTime: string,
  isAllDay: boolean
): string {
  if (isAllDay) {
    return `All day event: ${title}`;
  }
  return `Event: ${title}, from ${startTime} to ${endTime}`;
}

export function getDayAriaLabel(
  date: string,
  isToday: boolean,
  isWeekend: boolean,
  eventCount: number
): string {
  const parts = [date];
  
  if (isToday) parts.push('today');
  if (isWeekend) parts.push('weekend');
  
  parts.push(`${eventCount} event${eventCount !== 1 ? 's' : ''}`);
  
  return parts.join(', ');
}
