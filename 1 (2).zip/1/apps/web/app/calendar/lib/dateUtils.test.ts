import { describe, it, expect } from '@jest/globals';
import { DateTime } from 'luxon';
import { 
  isToday, 
  isWeekend, 
  snapToGrid, 
  getRelativeDateLabel,
  getMonthDays,
  getWeekDays,
  formatDateRange,
  getTimeSlots,
} from './dateUtils';

describe('dateUtils', () => {
  describe('isToday', () => {
    it('returns true for current date', () => {
      const today = DateTime.now();
      expect(isToday(today)).toBe(true);
    });

    it('returns false for yesterday', () => {
      const yesterday = DateTime.now().minus({ days: 1 });
      expect(isToday(yesterday)).toBe(false);
    });

    it('returns false for tomorrow', () => {
      const tomorrow = DateTime.now().plus({ days: 1 });
      expect(isToday(tomorrow)).toBe(false);
    });
  });

  describe('isWeekend', () => {
    it('returns true for Saturday', () => {
      const saturday = DateTime.local(2024, 1, 6);
      expect(isWeekend(saturday)).toBe(true);
    });

    it('returns true for Sunday', () => {
      const sunday = DateTime.local(2024, 1, 7);
      expect(isWeekend(sunday)).toBe(true);
    });

    it('returns false for weekdays', () => {
      const monday = DateTime.local(2024, 1, 8);
      expect(isWeekend(monday)).toBe(false);
    });
  });

  describe('snapToGrid', () => {
    it('snaps to 15-minute intervals - rounds down', () => {
      const time = DateTime.local(2024, 1, 1, 12, 7);
      const snapped = snapToGrid(time, 15);
      expect(snapped.minute).toBe(0);
    });

    it('snaps to 15-minute intervals - rounds up', () => {
      const time = DateTime.local(2024, 1, 1, 12, 8);
      const snapped = snapToGrid(time, 15);
      expect(snapped.minute).toBe(15);
    });

    it('snaps to 30-minute intervals', () => {
      const time = DateTime.local(2024, 1, 1, 12, 20);
      const snapped = snapToGrid(time, 30);
      expect(snapped.minute).toBe(30);
    });

    it('keeps exact grid times unchanged', () => {
      const time = DateTime.local(2024, 1, 1, 12, 15);
      const snapped = snapToGrid(time, 15);
      expect(snapped.minute).toBe(15);
    });
  });

  describe('getRelativeDateLabel', () => {
    it('returns "Today" for current date', () => {
      const today = DateTime.now().startOf('day');
      expect(getRelativeDateLabel(today)).toBe('Today');
    });

    it('returns "Tomorrow" for next day', () => {
      const tomorrow = DateTime.now().plus({ days: 1 }).startOf('day');
      expect(getRelativeDateLabel(tomorrow)).toBe('Tomorrow');
    });

    it('returns "Yesterday" for previous day', () => {
      const yesterday = DateTime.now().minus({ days: 1 }).startOf('day');
      expect(getRelativeDateLabel(yesterday)).toBe('Yesterday');
    });
  });

  describe('getMonthDays', () => {
    it('returns array of days for a month', () => {
      const january = DateTime.local(2024, 1, 15);
      const days = getMonthDays(january);
      expect(days.length).toBeGreaterThanOrEqual(28);
      expect(days.length).toBeLessThanOrEqual(42);
    });

    it('starts from the beginning of the week', () => {
      const january = DateTime.local(2024, 1, 15);
      const days = getMonthDays(january);
      expect(days[0].weekday).toBe(1);
    });
  });

  describe('getWeekDays', () => {
    it('returns exactly 7 days', () => {
      const date = DateTime.local(2024, 1, 15);
      const days = getWeekDays(date);
      expect(days).toHaveLength(7);
    });

    it('starts from Monday', () => {
      const date = DateTime.local(2024, 1, 15);
      const days = getWeekDays(date);
      expect(days[0].weekday).toBe(1);
    });
  });

  describe('formatDateRange', () => {
    it('formats same-day range correctly', () => {
      const start = DateTime.local(2024, 1, 15, 10, 0);
      const end = DateTime.local(2024, 1, 15, 11, 0);
      const formatted = formatDateRange(start, end);
      expect(formatted).toContain('10:00');
      expect(formatted).toContain('11:00');
    });

    it('formats multi-day range correctly', () => {
      const start = DateTime.local(2024, 1, 15, 10, 0);
      const end = DateTime.local(2024, 1, 16, 11, 0);
      const formatted = formatDateRange(start, end);
      expect(formatted).toContain('Jan 15');
      expect(formatted).toContain('Jan 16');
    });
  });

  describe('getTimeSlots', () => {
    it('returns 24 slots by default', () => {
      const slots = getTimeSlots();
      expect(slots).toHaveLength(24);
    });

    it('includes all hours from 0 to 23', () => {
      const slots = getTimeSlots();
      const hours = slots.map((s) => s.hour);
      expect(hours).toContain(0);
      expect(hours).toContain(12);
      expect(hours).toContain(23);
    });
  });
});
