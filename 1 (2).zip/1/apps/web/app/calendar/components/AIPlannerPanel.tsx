"use client";

import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  Sparkles, 
  Check, 
  X as XIcon, 
  RefreshCw,
  Lightbulb,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useCalendarStore } from '../store/calendarStore';
import { useDailyPlanner } from '../hooks/useDailyPlanner';
import type { SuggestedEvent } from '../types/calendar.types';
import { DateTime } from 'luxon';

interface SuggestionCardProps {
  suggestion: SuggestedEvent;
  onAccept: () => void;
  onDismiss: () => void;
}

function SuggestionCard({ suggestion, onAccept, onDismiss }: SuggestionCardProps) {
  const startTime = DateTime.fromISO(suggestion.startTime);
  const endTime = DateTime.fromISO(suggestion.endTime);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
      className="p-4 border rounded-lg bg-card"
      data-testid={`suggestion-${suggestion.id}`}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <h4 className="font-medium">{suggestion.title}</h4>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-green-600 hover:text-green-700 hover:bg-green-100"
            onClick={onAccept}
            aria-label="Accept suggestion"
            data-testid={`accept-${suggestion.id}`}
          >
            <Check className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-destructive"
            onClick={onDismiss}
            aria-label="Dismiss suggestion"
            data-testid={`dismiss-${suggestion.id}`}
          >
            <XIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
        <Clock className="h-3.5 w-3.5" />
        <span>
          {startTime.toFormat('h:mm a')} - {endTime.toFormat('h:mm a')}
        </span>
      </div>

      <p className="text-sm text-muted-foreground">
        {suggestion.reason}
      </p>
    </motion.div>
  );
}

export function AIPlannerPanel() {
  const { isAIPanelOpen } = useCalendarStore();
  const {
    dailyPlan,
    isLoading,
    handleAcceptSuggestion,
    handleDismissSuggestion,
    handleClosePanel,
    handleRefreshPlan,
  } = useDailyPlanner();

  return (
    <AnimatePresence>
      {isAIPanelOpen && (
        <motion.div
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 320, opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="border-l bg-muted/30 flex flex-col h-full overflow-hidden"
          data-testid="ai-planner-panel"
        >
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">AI Daily Planner</h3>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleRefreshPlan}
                disabled={isLoading}
                aria-label="Refresh plan"
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleClosePanel}
                aria-label="Close panel"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-4 space-y-4">
              {isLoading && (
                <div className="flex items-center justify-center py-8">
                  <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              )}

              {!isLoading && dailyPlan && (
                <>
                  <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                    <p className="text-sm">{dailyPlan.summary}</p>
                  </div>

                  {dailyPlan.suggestedEvents.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-medium text-muted-foreground">
                        Suggested Events
                      </h4>
                      <AnimatePresence>
                        {dailyPlan.suggestedEvents.map((suggestion) => (
                          <SuggestionCard
                            key={suggestion.id}
                            suggestion={suggestion}
                            onAccept={() => handleAcceptSuggestion(suggestion)}
                            onDismiss={() => handleDismissSuggestion(suggestion.id)}
                          />
                        ))}
                      </AnimatePresence>
                    </div>
                  )}

                  {dailyPlan.tips.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <Lightbulb className="h-4 w-4" />
                        Tips for Today
                      </h4>
                      <ul className="space-y-2">
                        {dailyPlan.tips.map((tip, index) => (
                          <li 
                            key={index}
                            className="text-sm text-muted-foreground pl-4 border-l-2 border-primary/30"
                          >
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}

              {!isLoading && !dailyPlan && (
                <div className="text-center py-8 text-muted-foreground">
                  <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No plan generated yet</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
