"use client";

import { useState } from 'react';
import { Plane, X, Car, Train, Footprints, Bike } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TRAVEL_MODES, type TravelTime } from '../types/calendar.types';

interface TravelTimeFieldProps {
  value?: TravelTime;
  onChange: (value: TravelTime | undefined) => void;
}

const modeIcons = {
  driving: Car,
  transit: Train,
  walking: Footprints,
  cycling: Bike,
};

export function TravelTimeField({ value, onChange }: TravelTimeFieldProps) {
  const [isAdding, setIsAdding] = useState(!!value);
  const [minutes, setMinutes] = useState(value?.minutes || 15);
  const [mode, setMode] = useState<TravelTime['mode']>(value?.mode || 'driving');

  const handleAdd = () => {
    setIsAdding(true);
    onChange({ minutes: 15, mode: 'driving' });
  };

  const handleRemove = () => {
    setIsAdding(false);
    setMinutes(15);
    setMode('driving');
    onChange(undefined);
  };

  const handleMinutesChange = (newMinutes: number) => {
    const validMinutes = Math.max(1, Math.min(480, newMinutes));
    setMinutes(validMinutes);
    onChange({ minutes: validMinutes, mode });
  };

  const handleModeChange = (newMode: TravelTime['mode']) => {
    setMode(newMode);
    onChange({ minutes, mode: newMode });
  };

  if (!isAdding) {
    return (
      <Button
        type="button"
        variant="ghost"
        className="justify-start gap-2 text-muted-foreground"
        onClick={handleAdd}
        data-testid="button-add-travel-time"
      >
        <Plane className="h-4 w-4" />
        Add travel time
      </Button>
    );
  }

  const ModeIcon = mode ? modeIcons[mode] : Car;

  return (
    <div className="space-y-3" data-testid="travel-time-field">
      <div className="flex items-center justify-between">
        <Label className="flex items-center gap-2">
          <Plane className="h-4 w-4" />
          Travel Time
        </Label>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={handleRemove}
          aria-label="Remove travel time"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex gap-2">
        <div className="flex items-center gap-2">
          <Input
            type="number"
            min={1}
            max={480}
            value={minutes}
            onChange={(e) => handleMinutesChange(parseInt(e.target.value) || 15)}
            className="w-20"
            data-testid="input-travel-minutes"
          />
          <span className="text-sm text-muted-foreground">minutes</span>
        </div>

        <Select value={mode} onValueChange={(v) => handleModeChange(v as TravelTime['mode'])}>
          <SelectTrigger className="w-[140px]">
            <div className="flex items-center gap-2">
              <ModeIcon className="h-4 w-4" />
              <SelectValue />
            </div>
          </SelectTrigger>
          <SelectContent>
            {TRAVEL_MODES.map((m) => {
              const Icon = modeIcons[m.id as keyof typeof modeIcons];
              return (
                <SelectItem key={m.id} value={m.id}>
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    {m.name}
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
      </div>

      <p className="text-xs text-muted-foreground">
        A {minutes}-minute buffer will be shown before this event
      </p>
    </div>
  );
}
