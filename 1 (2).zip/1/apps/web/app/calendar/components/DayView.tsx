"use client";

import { useMemo, useRef } from 'react';
import { useDroppable } from '@dnd-kit/core';
import { motion } from 'framer-motion';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { 
  isToday, 
  getEventsForDate, 
  getEventPositionInDay,
  getTimeSlots,
  calculateTravelBuffer,
} from '../lib/dateUtils';
import { EventPill } from './EventPill';
import { CALENDAR_COLORS, type CalendarEvent } from '../types/calendar.types';

const HOUR_HEIGHT = 60;
const TIME_SLOTS = getTimeSlots(60);

interface TimeRowProps {
  date: DateTime;
  hour: number;
}

function TimeRow({ date, hour }: TimeRowProps) {
  const dateKey = date.toISODate() || '';
  const cellId = `day-cell-${dateKey}-${hour}`;

  const { setNodeRef, isOver } = useDroppable({
    id: cellId,
    data: { date, hour, minute: 0, type: 'time-cell' },
  });

  return (
    <div
      ref={setNodeRef}
      className={`
        h-[60px] border-b relative
        ${isOver ? 'bg-primary/10' : 'hover:bg-muted/30'}
      `}
      data-testid={cellId}
    >
      <div className="absolute left-0 top-0 w-full h-px bg-border/50" />
      <div className="absolute left-0 top-1/4 w-full h-px bg-border/20" />
      <div className="absolute left-0 top-1/2 w-full h-px bg-border/30" />
      <div className="absolute left-0 top-3/4 w-full h-px bg-border/20" />
    </div>
  );
}

export function DayView() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { currentDate, userTimezone, calendars } = useCalendarStore();
  const { events, isLoading } = useCalendarData();

  const isTodayDate = isToday(currentDate);

  const dayEvents = useMemo(() => 
    getEventsForDate(events, currentDate, userTimezone),
    [events, currentDate, userTimezone]
  );

  const allDayEvents = useMemo(() => 
    dayEvents.filter((e) => e.isAllDay),
    [dayEvents]
  );

  const timedEvents = useMemo(() => 
    dayEvents.filter((e) => !e.isAllDay),
    [dayEvents]
  );

  const getCalendarColor = (calendarId: string) => {
    const calendar = calendars.find((c) => c.id === calendarId);
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div ref={containerRef} className="flex h-full overflow-auto" data-testid="day-view">
      <div className="sticky left-0 z-20 bg-background border-r w-20 flex-shrink-0">
        <div
          className={`
            px-2 py-3 text-center border-b
            ${isTodayDate ? 'bg-primary/5' : ''}
          `}
        >
          <div className="text-xs text-muted-foreground">
            {currentDate.toFormat('EEEE')}
          </div>
          <div
            className={`
              text-2xl font-bold mt-1 w-10 h-10 mx-auto flex items-center justify-center rounded-full
              ${isTodayDate ? 'bg-primary text-primary-foreground' : ''}
            `}
          >
            {currentDate.day}
          </div>
        </div>

        {allDayEvents.length > 0 && (
          <div className="h-auto min-h-[40px] border-b flex items-center justify-center px-1">
            <span className="text-xs text-muted-foreground">All-day</span>
          </div>
        )}

        <div className="relative">
          {TIME_SLOTS.map((slot) => (
            <div
              key={slot.hour}
              className="h-[60px] px-2 text-right text-xs text-muted-foreground relative flex items-start"
            >
              <span className="absolute -top-2 right-2">{slot.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1">
        <div className="sticky top-0 z-10 bg-background border-b h-[68px]" />

        {allDayEvents.length > 0 && (
          <div className="border-b bg-muted/20 px-2 py-1 space-y-1">
            {allDayEvents.map((event) => (
              <EventPill
                key={event.id}
                event={event}
                showTime={false}
              />
            ))}
          </div>
        )}

        <div className="relative">
          {TIME_SLOTS.map((slot) => (
            <TimeRow key={slot.hour} date={currentDate} hour={slot.hour} />
          ))}

          {timedEvents.map((event) => {
            const { top, height } = getEventPositionInDay(event, userTimezone, HOUR_HEIGHT);
            const color = getCalendarColor(event.calendarId);
            const travelBuffer = calculateTravelBuffer(event);

            return (
              <div key={event.id}>
                {travelBuffer && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute left-2 right-2 rounded-md flex items-center"
                    style={{
                      top: `${(travelBuffer.bufferStart.hour * 60 + travelBuffer.bufferStart.minute) / 60 * HOUR_HEIGHT}px`,
                      height: `${event.travelTime!.minutes}px`,
                      backgroundColor: `${color}15`,
                      borderLeft: `3px dashed ${color}50`,
                    }}
                    data-testid={`travel-buffer-${event.id}`}
                  >
                    <span className="text-xs text-muted-foreground px-3">
                      {event.travelTime!.minutes}m travel to {event.location || 'event'}
                    </span>
                  </motion.div>
                )}

                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute left-2 right-2"
                  style={{ 
                    top: `${top}px`, 
                    height: `${Math.max(height, 30)}px`,
                    minHeight: '30px'
                  }}
                >
                  <div 
                    className="h-full rounded-md overflow-hidden"
                    style={{ backgroundColor: `${color}10` }}
                  >
                    <EventPill
                      event={event}
                      showTime
                      className="h-full"
                    />
                  </div>
                </motion.div>
              </div>
            );
          })}

          {isTodayDate && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute left-0 right-0 h-0.5 bg-destructive z-20 pointer-events-none"
              style={{
                top: `${(DateTime.now().hour * 60 + DateTime.now().minute) / 60 * HOUR_HEIGHT}px`,
              }}
            >
              <div className="absolute -left-1 -top-1 w-2.5 h-2.5 rounded-full bg-destructive" />
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
