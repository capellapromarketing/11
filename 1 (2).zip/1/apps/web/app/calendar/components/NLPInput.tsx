"use client";

import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, Sparkles, Clock, MapPin, Calendar } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNLPInput } from '../hooks/useNLPInput';
import { DateTime } from 'luxon';

export function NLPInput() {
  const {
    inputValue,
    parsedEvent,
    isLoading,
    isInputFocused,
    inputRef,
    handleInputChange,
    handleClear,
    handleSubmit,
    handleKeyDown,
    setIsInputFocused,
  } = useNLPInput();

  const formatParsedTime = () => {
    if (!parsedEvent?.startTime) return null;
    const start = DateTime.fromISO(parsedEvent.startTime);
    const end = parsedEvent.endTime ? DateTime.fromISO(parsedEvent.endTime) : null;
    
    if (parsedEvent.isAllDay) {
      return start.toFormat('EEEE, MMMM d');
    }
    
    if (end) {
      return `${start.toFormat('EEE, MMM d')} at ${start.toFormat('h:mm a')} - ${end.toFormat('h:mm a')}`;
    }
    
    return `${start.toFormat('EEE, MMM d')} at ${start.toFormat('h:mm a')}`;
  };

  return (
    <div className="relative" data-testid="nlp-input-container">
      <div className="relative flex items-center">
        <div className="absolute left-3 flex items-center pointer-events-none">
          {isLoading ? (
            <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          ) : (
            <Sparkles className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
        
        <Input
          ref={inputRef}
          value={inputValue}
          onChange={(e) => handleInputChange(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsInputFocused(true)}
          onBlur={() => setTimeout(() => setIsInputFocused(false), 200)}
          placeholder="Quick add: 'Team lunch tomorrow at noon' or 'Meeting with Sarah Friday 2pm'"
          className="pl-10 pr-10 h-10"
          data-testid="input-nlp"
        />
        
        {inputValue && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-1 h-8 w-8"
            onClick={handleClear}
            aria-label="Clear input"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      <AnimatePresence>
        {parsedEvent && inputValue && (isInputFocused || parsedEvent) && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="absolute top-full left-0 right-0 mt-2 bg-popover border rounded-lg shadow-lg z-50 overflow-hidden"
            data-testid="nlp-preview"
          >
            <div className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-2">
                    {parsedEvent.title || 'New Event'}
                  </h4>
                  
                  <div className="space-y-1.5 text-sm text-muted-foreground">
                    {parsedEvent.startTime && (
                      <div className="flex items-center gap-2">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{formatParsedTime()}</span>
                        {parsedEvent.isAllDay && (
                          <Badge variant="secondary" className="text-xs">All day</Badge>
                        )}
                      </div>
                    )}
                    
                    {parsedEvent.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3.5 w-3.5" />
                        <span>{parsedEvent.location}</span>
                      </div>
                    )}
                  </div>
                </div>

                <Button
                  size="sm"
                  onClick={handleSubmit}
                  disabled={!parsedEvent.startTime}
                  data-testid="button-create-from-nlp"
                >
                  <Calendar className="h-4 w-4 mr-1" />
                  Create
                </Button>
              </div>

              {!parsedEvent.startTime && (
                <p className="text-xs text-muted-foreground mt-2 pt-2 border-t">
                  Add a time like "at 2pm" or "tomorrow" to create the event directly
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
