"use client";

import { useMemo } from 'react';
import { DragOverlay, useDndContext } from '@dnd-kit/core';
import { motion } from 'framer-motion';
import { GripVertical, Calendar } from 'lucide-react';
import { useCalendarStore } from '../store/calendarStore';
import { CALENDAR_COLORS, type CalendarEvent, type Task } from '../types/calendar.types';

interface DragPreviewProps {
  type: 'event' | 'task';
  event?: CalendarEvent;
  task?: Task;
}

function DragPreview({ type, event, task }: DragPreviewProps) {
  const { calendars } = useCalendarStore();

  const calendarColor = useMemo(() => {
    const calendarId = event?.calendarId;
    const calendar = calendars.find((c) => c.id === calendarId);
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  }, [calendars, event]);

  if (type === 'task' && task) {
    return (
      <motion.div
        initial={{ scale: 1 }}
        animate={{ scale: 1.02, boxShadow: '0 10px 40px rgba(0,0,0,0.15)' }}
        className="flex items-center gap-2 p-3 rounded-lg bg-background border-2 border-primary/50 min-w-[200px]"
      >
        <GripVertical className="h-4 w-4 text-muted-foreground" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{task.title}</p>
          <p className="text-xs text-muted-foreground">Converting to event...</p>
        </div>
        <Calendar className="h-4 w-4 text-primary" />
      </motion.div>
    );
  }

  if (type === 'event' && event) {
    return (
      <motion.div
        initial={{ scale: 1 }}
        animate={{ scale: 1.02, boxShadow: '0 10px 40px rgba(0,0,0,0.15)' }}
        className="flex items-center gap-2 px-3 py-2 rounded-md bg-background border min-w-[200px]"
        style={{ borderLeftColor: calendarColor, borderLeftWidth: 3 }}
      >
        <GripVertical className="h-4 w-4 text-muted-foreground" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{event.title}</p>
          <p className="text-xs text-muted-foreground">Moving event...</p>
        </div>
      </motion.div>
    );
  }

  return null;
}

export function DragLayer() {
  const { active } = useDndContext();
  const { events, tasks } = useCalendarStore();

  const activeData = useMemo(() => {
    if (!active) return null;

    const activeId = active.id as string;
    
    if (activeId.startsWith('task-')) {
      const task = tasks.find((t) => t.id === activeId);
      return task ? { type: 'task' as const, task } : null;
    } else {
      const event = events.find((e) => e.id === activeId);
      return event ? { type: 'event' as const, event } : null;
    }
  }, [active, events, tasks]);

  if (!activeData) return null;

  return (
    <DragOverlay dropAnimation={{ duration: 200, easing: 'ease-out' }}>
      <DragPreview
        type={activeData.type}
        event={activeData.type === 'event' ? activeData.event : undefined}
        task={activeData.type === 'task' ? activeData.task : undefined}
      />
    </DragOverlay>
  );
}
