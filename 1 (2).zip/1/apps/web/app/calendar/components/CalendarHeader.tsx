"use client";

import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon,
  Sparkles,
  Settings,
  Search,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { useCalendarStore } from '../store/calendarStore';
import { NLPInput } from './NLPInput';
import { useDailyPlanner } from '../hooks/useDailyPlanner';
import type { CalendarView } from '../types/calendar.types';

const VIEW_OPTIONS: { value: CalendarView; label: string }[] = [
  { value: 'month', label: 'Month' },
  { value: 'week', label: 'Week' },
  { value: 'day', label: 'Day' },
  { value: 'agenda', label: 'Agenda' },
];

export function CalendarHeader() {
  const { 
    currentDate, 
    view, 
    setView, 
    goToToday, 
    goToPrevious, 
    goToNext 
  } = useCalendarStore();
  
  const { handlePlanMyDay, isLoading: isPlanningDay } = useDailyPlanner();

  const headerTitle = useMemo(() => {
    switch (view) {
      case 'month':
        return currentDate.toFormat('MMMM yyyy');
      case 'week':
        const weekStart = currentDate.startOf('week');
        const weekEnd = currentDate.endOf('week');
        if (weekStart.month === weekEnd.month) {
          return `${weekStart.toFormat('MMMM d')} - ${weekEnd.toFormat('d, yyyy')}`;
        }
        return `${weekStart.toFormat('MMM d')} - ${weekEnd.toFormat('MMM d, yyyy')}`;
      case 'day':
        return currentDate.toFormat('EEEE, MMMM d, yyyy');
      case 'agenda':
        return 'Agenda';
      default:
        return currentDate.toFormat('MMMM yyyy');
    }
  }, [currentDate, view]);

  return (
    <header 
      className="flex flex-col gap-4 px-4 py-3 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
      data-testid="calendar-header"
    >
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={goToPrevious}
              aria-label="Previous"
              data-testid="button-previous"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={goToNext}
              aria-label="Next"
              data-testid="button-next"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>

          <motion.h1 
            key={headerTitle}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-xl font-semibold min-w-[200px]"
          >
            {headerTitle}
          </motion.h1>

          <Button
            variant="outline"
            size="sm"
            onClick={goToToday}
            className="gap-2"
            data-testid="button-today"
          >
            <CalendarIcon className="h-4 w-4" />
            Today
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <Select value={view} onValueChange={(v) => setView(v as CalendarView)}>
            <SelectTrigger className="w-[120px]" data-testid="select-view">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {VIEW_OPTIONS.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            size="sm"
            onClick={handlePlanMyDay}
            disabled={isPlanningDay}
            className="gap-2"
            data-testid="button-plan-my-day"
          >
            {isPlanningDay ? (
              <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4" />
            )}
            Plan My Day
          </Button>
        </div>
      </div>

      <NLPInput />
    </header>
  );
}
