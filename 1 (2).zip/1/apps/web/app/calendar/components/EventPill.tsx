"use client";

import { useMemo } from 'react';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { motion } from 'framer-motion';
import { DateTime } from 'luxon';
import { Video, RefreshCw, Plane } from 'lucide-react';
import { useCalendarStore } from '../store/calendarStore';
import { parseEventDateTime, convertToUserTimezone } from '../lib/dateUtils';
import { isRecurringEvent } from '../lib/recurrence';
import { CALENDAR_COLORS, type CalendarEvent } from '../types/calendar.types';
import { cn } from '@/lib/utils';

interface EventPillProps {
  event: CalendarEvent;
  compact?: boolean;
  showTime?: boolean;
  className?: string;
}

export function EventPill({ event, compact = false, showTime = true, className }: EventPillProps) {
  const { 
    calendars, 
    userTimezone, 
    isDragging, 
    draggedEventId,
    setSelectedEvent,
    setIsEventPopoverOpen,
  } = useCalendarStore();

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    isDragging: isThisDragging,
  } = useDraggable({
    id: event.id,
    data: { event, type: 'event' },
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    opacity: isThisDragging ? 0.5 : 1,
  };

  const calendar = useMemo(() => 
    calendars.find((c) => c.id === event.calendarId),
    [calendars, event.calendarId]
  );

  const calendarColor = useMemo(() => {
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  }, [calendar]);

  const { start, end } = useMemo(() => parseEventDateTime(event), [event]);
  const localStart = useMemo(() => convertToUserTimezone(start, userTimezone), [start, userTimezone]);

  const isRecurring = isRecurringEvent(event);
  const hasVideoCall = !!event.videoCall;
  const hasTravelTime = !!event.travelTime;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedEvent(event);
    setIsEventPopoverOpen(true);
  };

  if (compact) {
    return (
      <motion.div
        ref={setNodeRef}
        style={style}
        {...attributes}
        {...listeners}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleClick}
        className={cn(
          'flex items-center gap-1 px-1.5 py-0.5 rounded text-xs cursor-pointer truncate',
          'hover:brightness-95 transition-all',
          className
        )}
        style={{
          ...style,
          backgroundColor: `${calendarColor}20`,
          borderLeft: `3px solid ${calendarColor}`,
        }}
        data-testid={`event-pill-${event.id}`}
      >
        {showTime && !event.isAllDay && (
          <span className="text-muted-foreground flex-shrink-0">
            {localStart.toFormat('h:mm')}
          </span>
        )}
        <span className="truncate font-medium">{event.title}</span>
        {hasVideoCall && <Video className="h-3 w-3 flex-shrink-0 text-primary" />}
        {isRecurring && <RefreshCw className="h-3 w-3 flex-shrink-0 text-muted-foreground" />}
      </motion.div>
    );
  }

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={handleClick}
      className={cn(
        'px-2 py-1.5 rounded-md cursor-pointer overflow-hidden',
        'hover:brightness-95 transition-all',
        className
      )}
      style={{
        ...style,
        backgroundColor: `${calendarColor}15`,
        borderLeft: `4px solid ${calendarColor}`,
      }}
      data-testid={`event-pill-${event.id}`}
    >
      <div className="flex items-start justify-between gap-1">
        <div className="min-w-0 flex-1">
          <p className="font-medium text-sm truncate">{event.title}</p>
          {showTime && !event.isAllDay && (
            <p className="text-xs text-muted-foreground">
              {localStart.toFormat('h:mm a')}
            </p>
          )}
          {event.location && (
            <p className="text-xs text-muted-foreground truncate mt-0.5">
              {event.location}
            </p>
          )}
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {hasVideoCall && <Video className="h-3.5 w-3.5 text-primary" />}
          {isRecurring && <RefreshCw className="h-3.5 w-3.5 text-muted-foreground" />}
          {hasTravelTime && <Plane className="h-3.5 w-3.5 text-muted-foreground" />}
        </div>
      </div>
    </motion.div>
  );
}
