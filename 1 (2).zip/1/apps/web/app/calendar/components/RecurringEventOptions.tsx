"use client";

import { DateTime } from 'luxon';
import { RefreshCw } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import type { RecurrenceFrequency } from '../types/calendar.types';

interface RecurringEventOptionsProps {
  isRecurring: boolean;
  frequency: RecurrenceFrequency;
  interval: number;
  selectedDays: number[];
  hasEndDate: boolean;
  endDate: DateTime | null;
  repeatCount: number | null;
  onIsRecurringChange: (value: boolean) => void;
  onFrequencyChange: (value: RecurrenceFrequency) => void;
  onIntervalChange: (value: number) => void;
  onSelectedDaysChange: (value: number[]) => void;
  onHasEndDateChange: (value: boolean) => void;
  onEndDateChange: (value: DateTime | null) => void;
  onRepeatCountChange: (value: number | null) => void;
}

const WEEKDAYS = [
  { value: 0, label: 'M' },
  { value: 1, label: 'T' },
  { value: 2, label: 'W' },
  { value: 3, label: 'T' },
  { value: 4, label: 'F' },
  { value: 5, label: 'S' },
  { value: 6, label: 'S' },
];

export function RecurringEventOptions({
  isRecurring,
  frequency,
  interval,
  selectedDays,
  hasEndDate,
  endDate,
  repeatCount,
  onIsRecurringChange,
  onFrequencyChange,
  onIntervalChange,
  onSelectedDaysChange,
  onHasEndDateChange,
  onEndDateChange,
  onRepeatCountChange,
}: RecurringEventOptionsProps) {
  const handleDayToggle = (dayValue: string[]) => {
    onSelectedDaysChange(dayValue.map((v) => parseInt(v)));
  };

  return (
    <div className="space-y-4" data-testid="recurring-options">
      <div className="flex items-center justify-between">
        <Label className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Repeat
        </Label>
        <Switch
          checked={isRecurring}
          onCheckedChange={onIsRecurringChange}
          data-testid="switch-recurring"
        />
      </div>

      {isRecurring && (
        <div className="space-y-4 pl-6 border-l-2 border-muted ml-2">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Every</span>
            <Input
              type="number"
              min={1}
              max={99}
              value={interval}
              onChange={(e) => onIntervalChange(parseInt(e.target.value) || 1)}
              className="w-16 h-8"
              data-testid="input-interval"
            />
            <Select value={frequency} onValueChange={(v) => onFrequencyChange(v as RecurrenceFrequency)}>
              <SelectTrigger className="w-[100px] h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">day(s)</SelectItem>
                <SelectItem value="weekly">week(s)</SelectItem>
                <SelectItem value="monthly">month(s)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {frequency === 'weekly' && (
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Repeat on</Label>
              <ToggleGroup
                type="multiple"
                value={selectedDays.map((d) => d.toString())}
                onValueChange={handleDayToggle}
                className="justify-start"
              >
                {WEEKDAYS.map((day) => (
                  <ToggleGroupItem
                    key={day.value}
                    value={day.value.toString()}
                    aria-label={day.label}
                    className="w-8 h-8 text-xs"
                    data-testid={`toggle-day-${day.value}`}
                  >
                    {day.label}
                  </ToggleGroupItem>
                ))}
              </ToggleGroup>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Switch
                checked={hasEndDate}
                onCheckedChange={onHasEndDateChange}
                id="has-end-date"
              />
              <Label htmlFor="has-end-date" className="text-sm">
                End date
              </Label>
            </div>

            {hasEndDate && (
              <Input
                type="date"
                value={endDate?.toISODate() || ''}
                onChange={(e) => {
                  const date = e.target.value ? DateTime.fromISO(e.target.value) : null;
                  onEndDateChange(date);
                }}
                className="h-8 w-full"
                data-testid="input-end-date"
              />
            )}

            {!hasEndDate && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Or after</span>
                <Input
                  type="number"
                  min={1}
                  max={999}
                  value={repeatCount || ''}
                  onChange={(e) => onRepeatCountChange(e.target.value ? parseInt(e.target.value) : null)}
                  placeholder="∞"
                  className="w-20 h-8"
                  data-testid="input-repeat-count"
                />
                <span className="text-sm text-muted-foreground">occurrences</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
