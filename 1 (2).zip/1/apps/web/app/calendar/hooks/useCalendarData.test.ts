import { renderHook, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';
import { describe, it, expect } from '@jest/globals';
import { useCalendarData } from './useCalendarData';

const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: { 
      queries: { 
        retry: false,
        staleTime: 0,
      } 
    },
  });
  
  return function Wrapper({ children }: { children: React.ReactNode }) {
    return React.createElement(
      QueryClientProvider,
      { client: queryClient },
      children
    );
  };
};

describe('useCalendarData', () => {
  it('initializes with loading state', () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    expect(result.current.isLoading).toBeDefined();
  });

  it('fetches calendar events', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    await waitFor(() => expect(result.current.isLoading).toBe(false), {
      timeout: 5000,
    });
    
    expect(result.current.events).toBeDefined();
    expect(Array.isArray(result.current.events)).toBe(true);
  });

  it('fetches calendars', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    await waitFor(() => expect(result.current.isLoading).toBe(false), {
      timeout: 5000,
    });
    
    expect(result.current.calendars).toBeDefined();
    expect(Array.isArray(result.current.calendars)).toBe(true);
  });

  it('fetches tasks', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    await waitFor(() => expect(result.current.isLoading).toBe(false), {
      timeout: 5000,
    });
    
    expect(result.current.tasks).toBeDefined();
    expect(Array.isArray(result.current.tasks)).toBe(true);
  });

  it('provides mutation functions', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    expect(result.current.createEvent).toBeDefined();
    expect(typeof result.current.createEvent).toBe('function');
    
    expect(result.current.updateEvent).toBeDefined();
    expect(typeof result.current.updateEvent).toBe('function');
    
    expect(result.current.deleteEvent).toBeDefined();
    expect(typeof result.current.deleteEvent).toBe('function');
  });

  it('provides mutation loading states', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    expect(result.current.isCreating).toBe(false);
    expect(result.current.isUpdating).toBe(false);
    expect(result.current.isDeleting).toBe(false);
  });

  it('provides refetch function', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    expect(result.current.refetch).toBeDefined();
    expect(typeof result.current.refetch).toBe('function');
  });

  it('handles errors gracefully', async () => {
    const { result } = renderHook(() => useCalendarData(), {
      wrapper: createWrapper(),
    });

    await waitFor(() => expect(result.current.isLoading).toBe(false), {
      timeout: 5000,
    });
    
    expect(result.current.isError).toBe(false);
    expect(result.current.error).toBeNull();
  });
});
