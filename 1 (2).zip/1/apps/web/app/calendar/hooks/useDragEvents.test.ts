import { renderHook, act } from '@testing-library/react';
import { describe, it, expect } from '@jest/globals';
import type { DragStartEvent, DragEndEvent } from '@dnd-kit/core';

describe('useDragEvents', () => {
  it('initializes with no active drag', async () => {
    const { useDragEvents } = await import('./useDragEvents');
    const { result } = renderHook(() => useDragEvents());
    
    expect(result.current.activeId).toBeNull();
    expect(result.current.isDragging).toBe(false);
    expect(result.current.activeType).toBeNull();
  });

  it('provides drag handler functions', async () => {
    const { useDragEvents } = await import('./useDragEvents');
    const { result } = renderHook(() => useDragEvents());

    expect(result.current.handleDragStart).toBeDefined();
    expect(typeof result.current.handleDragStart).toBe('function');
    
    expect(result.current.handleDragEnd).toBeDefined();
    expect(typeof result.current.handleDragEnd).toBe('function');
    
    expect(result.current.handleDragMove).toBeDefined();
    expect(typeof result.current.handleDragMove).toBe('function');
    
    expect(result.current.handleDragCancel).toBeDefined();
    expect(typeof result.current.handleDragCancel).toBe('function');
  });

  it('exposes drag state properties', async () => {
    const { useDragEvents } = await import('./useDragEvents');
    const { result } = renderHook(() => useDragEvents());

    expect(result.current.dragState).toBeDefined();
    expect(result.current.previewStart).toBeNull();
    expect(result.current.previewEnd).toBeNull();
  });

  it('handles drag cancel', async () => {
    const { useDragEvents } = await import('./useDragEvents');
    const { result } = renderHook(() => useDragEvents());

    act(() => {
      result.current.handleDragCancel();
    });

    expect(result.current.isDragging).toBe(false);
    expect(result.current.activeId).toBeNull();
  });

  it('returns correct initial drag state shape', async () => {
    const { useDragEvents } = await import('./useDragEvents');
    const { result } = renderHook(() => useDragEvents());

    const { dragState } = result.current;
    
    expect(dragState).toHaveProperty('activeId');
    expect(dragState).toHaveProperty('activeType');
    expect(dragState).toHaveProperty('originalEvent');
    expect(dragState).toHaveProperty('originalTask');
    expect(dragState).toHaveProperty('previewStart');
    expect(dragState).toHaveProperty('previewEnd');
  });
});
