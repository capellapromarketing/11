"use client";

import type { DateTime } from 'luxon';

export type CalendarView = 'month' | 'week' | 'day' | 'agenda';

export type RecurrenceFrequency = 'daily' | 'weekly' | 'monthly';

export type RecurrenceEditMode = 'single' | 'thisAndFollowing' | 'all';

export interface RecurrenceRule {
  frequency: RecurrenceFrequency;
  interval: number;
  until?: string;
  count?: number;
  byDay?: number[];
}

export interface VideoCallInfo {
  provider: 'zoom' | 'google_meet' | 'teams' | 'webex';
  link: string;
}

export interface TravelTime {
  minutes: number;
  mode?: 'driving' | 'transit' | 'walking' | 'cycling';
}

export interface Attendee {
  id: string;
  email: string;
  name?: string;
  status: 'pending' | 'accepted' | 'declined' | 'tentative';
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  timezone: string;
  isAllDay: boolean;
  calendarId: string;
  location?: string;
  recurrence?: RecurrenceRule;
  recurrenceId?: string;
  isRecurrenceException?: boolean;
  videoCall?: VideoCallInfo;
  travelTime?: TravelTime;
  attendees?: Attendee[];
}

export interface Calendar {
  id: string;
  name: string;
  color: CalendarColorId;
  isDefault: boolean;
  isVisible: boolean;
}

export interface Task {
  id: string;
  title: string;
  dueDate?: string;
  priority: 'low' | 'medium' | 'high';
  isCompleted: boolean;
  estimatedMinutes?: number;
}

export interface ParsedEvent {
  title: string;
  startTime?: string;
  endTime?: string;
  isAllDay?: boolean;
  location?: string;
}

export interface SuggestedEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  reason: string;
}

export interface DailyPlan {
  summary: string;
  suggestedEvents: SuggestedEvent[];
  tips: string[];
}

export type CalendarColorId =
  | 'red'
  | 'orange'
  | 'yellow'
  | 'green'
  | 'teal'
  | 'blue'
  | 'indigo'
  | 'purple'
  | 'pink'
  | 'gray';

export interface CalendarColor {
  id: CalendarColorId;
  name: string;
  hex: string;
  bgClass: string;
  textClass: string;
}

export const CALENDAR_COLORS: CalendarColor[] = [
  { id: 'red', name: 'Red', hex: '#FF3B30', bgClass: 'bg-red-500', textClass: 'text-red-500' },
  { id: 'orange', name: 'Orange', hex: '#FF9500', bgClass: 'bg-orange-500', textClass: 'text-orange-500' },
  { id: 'yellow', name: 'Yellow', hex: '#FFCC00', bgClass: 'bg-yellow-500', textClass: 'text-yellow-500' },
  { id: 'green', name: 'Green', hex: '#34C759', bgClass: 'bg-green-500', textClass: 'text-green-500' },
  { id: 'teal', name: 'Teal', hex: '#5AC8FA', bgClass: 'bg-teal-500', textClass: 'text-teal-500' },
  { id: 'blue', name: 'Blue', hex: '#007AFF', bgClass: 'bg-blue-500', textClass: 'text-blue-500' },
  { id: 'indigo', name: 'Indigo', hex: '#5856D6', bgClass: 'bg-indigo-500', textClass: 'text-indigo-500' },
  { id: 'purple', name: 'Purple', hex: '#AF52DE', bgClass: 'bg-purple-500', textClass: 'text-purple-500' },
  { id: 'pink', name: 'Pink', hex: '#FF2D55', bgClass: 'bg-pink-500', textClass: 'text-pink-500' },
  { id: 'gray', name: 'Gray', hex: '#8E8E93', bgClass: 'bg-gray-500', textClass: 'text-gray-500' },
];

export const VIDEO_PROVIDERS = [
  { id: 'zoom', name: 'Zoom', icon: 'video' },
  { id: 'google_meet', name: 'Google Meet', icon: 'video' },
  { id: 'teams', name: 'Microsoft Teams', icon: 'video' },
  { id: 'webex', name: 'Webex', icon: 'video' },
] as const;

export const TRAVEL_MODES = [
  { id: 'driving', name: 'Driving', icon: 'car' },
  { id: 'transit', name: 'Public Transit', icon: 'train' },
  { id: 'walking', name: 'Walking', icon: 'footprints' },
  { id: 'cycling', name: 'Cycling', icon: 'bike' },
] as const;

export const COMMON_TIMEZONES = [
  { value: 'America/New_York', label: 'Eastern Time (ET)' },
  { value: 'America/Chicago', label: 'Central Time (CT)' },
  { value: 'America/Denver', label: 'Mountain Time (MT)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
  { value: 'America/Anchorage', label: 'Alaska Time (AKT)' },
  { value: 'Pacific/Honolulu', label: 'Hawaii Time (HT)' },
  { value: 'Europe/London', label: 'London (GMT/BST)' },
  { value: 'Europe/Paris', label: 'Central European (CET)' },
  { value: 'Europe/Berlin', label: 'Berlin (CET)' },
  { value: 'Asia/Tokyo', label: 'Japan (JST)' },
  { value: 'Asia/Shanghai', label: 'China (CST)' },
  { value: 'Asia/Kolkata', label: 'India (IST)' },
  { value: 'Australia/Sydney', label: 'Sydney (AEST)' },
  { value: 'UTC', label: 'UTC' },
] as const;
