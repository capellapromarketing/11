import { Video, Link as LinkIcon, X } from 'lucide-react';
import { SiZoom, SiGooglemeet } from 'react-icons/si';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import type { VideoCallProvider, VideoCallInfo } from '../types/calendar.types';

const VIDEO_PROVIDERS = [
  { value: 'zoom' as VideoCallProvider, label: 'Zoom', icon: SiZoom },
  { value: 'meet' as VideoCallProvider, label: 'Google Meet', icon: SiGooglemeet },
  { value: 'teams' as VideoCallProvider, label: 'Microsoft Teams', icon: Video },
];

interface VideoCallPickerProps {
  value: VideoCallInfo | undefined;
  onChange: (value: VideoCallInfo | undefined) => void;
}

export function VideoCallPicker({ value, onChange }: VideoCallPickerProps) {
  const handleProviderChange = (provider: VideoCallProvider) => {
    onChange({
      provider,
      link: value?.link || '',
    });
  };

  const handleLinkChange = (link: string) => {
    if (value) {
      onChange({
        ...value,
        link,
      });
    }
  };

  const handleClear = () => {
    onChange(undefined);
  };

  const handleAddVideoCall = () => {
    onChange({
      provider: 'zoom',
      link: '',
    });
  };

  if (!value) {
    return (
      <Button
        type="button"
        variant="outline"
        className="w-full justify-start text-muted-foreground"
        onClick={handleAddVideoCall}
        data-testid="button-add-video-call"
      >
        <Video className="h-4 w-4 mr-2" />
        Add video call
      </Button>
    );
  }

  const SelectedIcon = VIDEO_PROVIDERS.find((p) => p.value === value.provider)?.icon || Video;

  return (
    <div className="space-y-3" data-testid="video-call-picker">
      <div className="flex items-center justify-between">
        <Label className="text-sm text-muted-foreground flex items-center gap-2">
          <Video className="h-4 w-4" />
          Video Call
        </Label>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={handleClear}
          aria-label="Remove video call"
          data-testid="button-remove-video-call"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex gap-2">
        <Select
          value={value.provider}
          onValueChange={(v) => handleProviderChange(v as VideoCallProvider)}
        >
          <SelectTrigger 
            className="w-40 h-9"
            aria-label="Select video provider"
            data-testid="select-video-provider"
          >
            <SelectValue>
              <div className="flex items-center gap-2">
                <SelectedIcon className="h-4 w-4" />
                {VIDEO_PROVIDERS.find((p) => p.value === value.provider)?.label}
              </div>
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {VIDEO_PROVIDERS.map((provider) => (
              <SelectItem key={provider.value} value={provider.value}>
                <div className="flex items-center gap-2">
                  <provider.icon className="h-4 w-4" />
                  {provider.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex-1 relative">
          <LinkIcon className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="url"
            placeholder="Meeting link..."
            value={value.link}
            onChange={(e) => handleLinkChange(e.target.value)}
            className="pl-8 h-9"
            aria-label="Video meeting link"
            data-testid="input-video-link"
          />
        </div>
      </div>

      {value.link && (
        <a
          href={value.link}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-primary hover:underline flex items-center gap-1"
        >
          Open link
          <LinkIcon className="h-3 w-3" />
        </a>
      )}
    </div>
  );
}
