import { useMemo } from 'react';
import { DateTime } from 'luxon';
import { RefreshCw } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import type { RecurrenceFrequency } from '../types/calendar.types';

const WEEKDAYS = [
  { value: 0, label: 'Mon' },
  { value: 1, label: 'Tue' },
  { value: 2, label: 'Wed' },
  { value: 3, label: 'Thu' },
  { value: 4, label: 'Fri' },
  { value: 5, label: 'Sat' },
  { value: 6, label: 'Sun' },
];

interface RecurringEventOptionsProps {
  isRecurring: boolean;
  frequency: RecurrenceFrequency;
  interval: number;
  selectedDays: number[];
  hasEndDate: boolean;
  endDate: DateTime | null;
  repeatCount: number | null;
  onIsRecurringChange: (value: boolean) => void;
  onFrequencyChange: (value: RecurrenceFrequency) => void;
  onIntervalChange: (value: number) => void;
  onSelectedDaysChange: (days: number[]) => void;
  onHasEndDateChange: (value: boolean) => void;
  onEndDateChange: (date: DateTime | null) => void;
  onRepeatCountChange: (count: number | null) => void;
}

export function RecurringEventOptions({
  isRecurring,
  frequency,
  interval,
  selectedDays,
  hasEndDate,
  endDate,
  repeatCount,
  onIsRecurringChange,
  onFrequencyChange,
  onIntervalChange,
  onSelectedDaysChange,
  onHasEndDateChange,
  onEndDateChange,
  onRepeatCountChange,
}: RecurringEventOptionsProps) {
  const frequencyLabel = useMemo(() => {
    switch (frequency) {
      case 'daily': return interval === 1 ? 'day' : 'days';
      case 'weekly': return interval === 1 ? 'week' : 'weeks';
      case 'monthly': return interval === 1 ? 'month' : 'months';
    }
  }, [frequency, interval]);

  const toggleDay = (dayValue: number) => {
    if (selectedDays.includes(dayValue)) {
      onSelectedDaysChange(selectedDays.filter((d) => d !== dayValue));
    } else {
      onSelectedDaysChange([...selectedDays, dayValue]);
    }
  };

  return (
    <div className="space-y-4" data-testid="recurring-options">
      <div className="flex items-center justify-between">
        <Label htmlFor="recurring-toggle" className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Repeat
        </Label>
        <Switch
          id="recurring-toggle"
          checked={isRecurring}
          onCheckedChange={onIsRecurringChange}
          aria-label="Toggle recurring event"
          data-testid="switch-recurring"
        />
      </div>

      {isRecurring && (
        <div className="space-y-4 pl-6 border-l-2 border-muted">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Every</span>
            <Input
              type="number"
              min={1}
              max={99}
              value={interval}
              onChange={(e) => onIntervalChange(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-16 h-8"
              aria-label="Repeat interval"
              data-testid="input-interval"
            />
            <Select
              value={frequency}
              onValueChange={(value) => onFrequencyChange(value as RecurrenceFrequency)}
            >
              <SelectTrigger 
                className="w-28 h-8"
                aria-label="Repeat frequency"
                data-testid="select-frequency"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Day{interval > 1 ? 's' : ''}</SelectItem>
                <SelectItem value="weekly">Week{interval > 1 ? 's' : ''}</SelectItem>
                <SelectItem value="monthly">Month{interval > 1 ? 's' : ''}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {frequency === 'weekly' && (
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">On days</Label>
              <div className="flex gap-1">
                {WEEKDAYS.map((day) => (
                  <Button
                    key={day.value}
                    type="button"
                    variant={selectedDays.includes(day.value) ? 'default' : 'outline'}
                    size="sm"
                    className="h-8 w-10 px-0"
                    onClick={() => toggleDay(day.value)}
                    aria-label={`Repeat on ${day.label}`}
                    aria-pressed={selectedDays.includes(day.value)}
                    data-testid={`button-day-${day.value}`}
                  >
                    {day.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <Label className="text-sm text-muted-foreground">Ends</Label>
            
            <div className="space-y-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <Checkbox
                  checked={!hasEndDate && !repeatCount}
                  onCheckedChange={() => {
                    onHasEndDateChange(false);
                    onRepeatCountChange(null);
                  }}
                  data-testid="checkbox-never-ends"
                />
                <span className="text-sm">Never</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <Checkbox
                  checked={hasEndDate}
                  onCheckedChange={(checked) => {
                    onHasEndDateChange(!!checked);
                    if (checked) onRepeatCountChange(null);
                  }}
                  data-testid="checkbox-end-date"
                />
                <span className="text-sm">On date</span>
                {hasEndDate && (
                  <Input
                    type="date"
                    value={endDate?.toISODate() || ''}
                    onChange={(e) => onEndDateChange(e.target.value ? DateTime.fromISO(e.target.value) : null)}
                    className="h-8 w-40"
                    aria-label="End date"
                    data-testid="input-end-date"
                  />
                )}
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <Checkbox
                  checked={!!repeatCount}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      onRepeatCountChange(10);
                      onHasEndDateChange(false);
                    } else {
                      onRepeatCountChange(null);
                    }
                  }}
                  data-testid="checkbox-repeat-count"
                />
                <span className="text-sm">After</span>
                {repeatCount && (
                  <>
                    <Input
                      type="number"
                      min={1}
                      max={999}
                      value={repeatCount}
                      onChange={(e) => onRepeatCountChange(Math.max(1, parseInt(e.target.value) || 1))}
                      className="h-8 w-16"
                      aria-label="Number of occurrences"
                      data-testid="input-repeat-count"
                    />
                    <span className="text-sm">occurrences</span>
                  </>
                )}
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
