import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Shield, Calendar, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCalendarStore } from '../store/calendarStore';
import { useDailyPlanner } from '../hooks/useDailyPlanner';

export function AIConsentModal() {
  const { isAIConsentModalOpen } = useCalendarStore();
  const { handleAcceptConsent, handleDeclineConsent } = useDailyPlanner();

  return (
    <AnimatePresence>
      {isAIConsentModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          <div 
            className="absolute inset-0 bg-black/50" 
            onClick={handleDeclineConsent}
            aria-hidden="true"
          />
          
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="relative bg-background rounded-lg shadow-xl max-w-md w-full overflow-hidden"
            role="dialog"
            aria-modal="true"
            aria-labelledby="ai-consent-title"
            data-testid="ai-consent-modal"
          >
            <div className="p-6">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>

              <h2 
                id="ai-consent-title"
                className="text-xl font-semibold text-center mb-2"
              >
                Enable AI Planning?
              </h2>

              <p className="text-sm text-muted-foreground text-center mb-6">
                Let AI help you plan your day by analyzing your calendar and suggesting 
                optimal time blocks for focused work, meetings, and breaks.
              </p>

              <div className="space-y-3 mb-6">
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <Calendar className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Calendar Analysis</p>
                    <p className="text-xs text-muted-foreground">
                      We'll analyze your existing events to find the best times for new activities
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <Brain className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Smart Suggestions</p>
                    <p className="text-xs text-muted-foreground">
                      Get personalized recommendations based on your productivity patterns
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <Shield className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Your Data is Safe</p>
                    <p className="text-xs text-muted-foreground">
                      Your calendar data is processed securely and never shared with third parties
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleDeclineConsent}
                  data-testid="button-decline-ai"
                >
                  Not Now
                </Button>
                <Button
                  className="flex-1"
                  onClick={handleAcceptConsent}
                  data-testid="button-accept-ai"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Enable AI
                </Button>
              </div>

              <p className="text-xs text-muted-foreground text-center mt-4">
                You can disable this feature anytime in settings
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
