import { useMemo, useRef } from 'react';
import { useDroppable } from '@dnd-kit/core';
import { motion } from 'framer-motion';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { 
  getWeekDays, 
  isToday, 
  getEventsForDate, 
  getEventPositionInDay,
  getTimeSlots,
  calculateTravelBuffer,
  convertToUserTimezone,
  parseEventDateTime
} from '../lib/dateUtils';
import { EventPill } from './EventPill';
import { CALENDAR_COLORS, type CalendarEvent, type TimeSlot } from '../types/calendar.types';

const HOUR_HEIGHT = 60;
const TIME_SLOTS = getTimeSlots(60);

interface TimeGridCellProps {
  date: DateTime;
  hour: number;
}

function TimeGridCell({ date, hour }: TimeGridCellProps) {
  const dateKey = date.toISODate() || '';
  const cellId = `cell-${dateKey}-${hour}`;

  const { setNodeRef, isOver } = useDroppable({
    id: cellId,
    data: { date, hour, minute: 0, type: 'time-cell' },
  });

  return (
    <div
      ref={setNodeRef}
      className={`
        h-[60px] border-b border-r relative
        ${isOver ? 'bg-primary/10' : 'hover:bg-muted/30'}
      `}
      data-testid={cellId}
    >
      {[0, 15, 30, 45].map((minute) => (
        <div
          key={minute}
          className="absolute left-0 right-0 h-[15px]"
          style={{ top: `${(minute / 60) * 100}%` }}
        />
      ))}
    </div>
  );
}

interface DayColumnProps {
  date: DateTime;
  events: CalendarEvent[];
}

function DayColumn({ date, events }: DayColumnProps) {
  const { userTimezone, calendars } = useCalendarStore();
  const isTodayDate = isToday(date);
  const dateKey = date.toISODate() || '';

  const allDayEvents = events.filter((e) => e.isAllDay);
  const timedEvents = events.filter((e) => !e.isAllDay);

  const getCalendarColor = (calendarId: string) => {
    const calendar = calendars.find((c) => c.id === calendarId);
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  };

  return (
    <div className="flex flex-col flex-1 min-w-[120px]" data-testid={`week-day-column-${dateKey}`}>
      <div
        className={`
          sticky top-0 z-10 px-2 py-3 text-center border-b border-r bg-background
          ${isTodayDate ? 'bg-primary/5' : ''}
        `}
      >
        <div className="text-xs text-muted-foreground">{date.toFormat('EEE')}</div>
        <div
          className={`
            text-lg font-semibold mt-0.5 w-8 h-8 mx-auto flex items-center justify-center rounded-full
            ${isTodayDate ? 'bg-primary text-primary-foreground' : ''}
          `}
        >
          {date.day}
        </div>
      </div>

      {allDayEvents.length > 0 && (
        <div className="px-1 py-1 border-b border-r bg-muted/20 space-y-0.5">
          {allDayEvents.slice(0, 2).map((event) => (
            <EventPill
              key={event.id}
              event={event}
              compact
              showTime={false}
            />
          ))}
          {allDayEvents.length > 2 && (
            <span className="text-xs text-muted-foreground px-1">
              +{allDayEvents.length - 2} more
            </span>
          )}
        </div>
      )}

      <div className="relative flex-1">
        {TIME_SLOTS.map((slot) => (
          <TimeGridCell key={slot.hour} date={date} hour={slot.hour} />
        ))}

        {timedEvents.map((event) => {
          const { top, height } = getEventPositionInDay(event, userTimezone, HOUR_HEIGHT);
          const color = getCalendarColor(event.calendarId);

          const travelBuffer = calculateTravelBuffer(event);

          return (
            <div key={event.id}>
              {travelBuffer && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute left-1 right-1 rounded-md"
                  style={{
                    top: `${(travelBuffer.bufferStart.hour * 60 + travelBuffer.bufferStart.minute) / 60 * HOUR_HEIGHT}px`,
                    height: `${event.travelTime!.minutes}px`,
                    backgroundColor: `${color}20`,
                    borderLeft: `3px dashed ${color}`,
                  }}
                  data-testid={`travel-buffer-${event.id}`}
                >
                  <span className="text-xs text-muted-foreground px-2">
                    {event.travelTime!.minutes}m travel
                  </span>
                </motion.div>
              )}

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute left-1 right-1"
                style={{ top: `${top}px`, height: `${height}px`, minHeight: '20px' }}
              >
                <EventPill
                  event={event}
                  showTime
                  className="h-full"
                  style={{
                    backgroundColor: `${color}15`,
                  }}
                />
              </motion.div>
            </div>
          );
        })}

        {isTodayDate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute left-0 right-0 h-0.5 bg-destructive z-20 pointer-events-none"
            style={{
              top: `${(DateTime.now().hour * 60 + DateTime.now().minute) / 60 * HOUR_HEIGHT}px`,
            }}
          >
            <div className="absolute -left-1 -top-1 w-2 h-2 rounded-full bg-destructive" />
          </motion.div>
        )}
      </div>
    </div>
  );
}

export function WeekView() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { currentDate, userTimezone } = useCalendarStore();
  const { events, isLoading } = useCalendarData();

  const weekDays = useMemo(() => getWeekDays(currentDate), [currentDate]);

  const eventsPerDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    weekDays.forEach((day) => {
      const dateKey = day.toISODate();
      if (dateKey) {
        const dayEvents = getEventsForDate(events, day, userTimezone);
        map.set(dateKey, dayEvents);
      }
    });
    return map;
  }, [events, weekDays, userTimezone]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div ref={containerRef} className="flex h-full overflow-auto" data-testid="week-view">
      <div className="sticky left-0 z-20 bg-background border-r w-16 flex-shrink-0">
        <div className="h-[68px] border-b" />
        <div className="relative">
          {TIME_SLOTS.map((slot) => (
            <div
              key={slot.hour}
              className="h-[60px] pr-2 text-right text-xs text-muted-foreground relative"
            >
              <span className="absolute -top-2 right-2">{slot.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-1">
        {weekDays.map((day) => {
          const dateKey = day.toISODate() || '';
          const dayEvents = eventsPerDay.get(dateKey) || [];

          return (
            <DayColumn key={dateKey} date={day} events={dayEvents} />
          );
        })}
      </div>
    </div>
  );
}
