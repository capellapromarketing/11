import { useMemo, useState } from 'react';
import { DateTime } from 'luxon';
import { Globe, Check, Search } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatTimezoneOffset } from '../lib/dateUtils';

const COMMON_TIMEZONES = [
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'America/Toronto',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Europe/Amsterdam',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Asia/Hong_Kong',
  'Asia/Singapore',
  'Asia/Kolkata',
  'Asia/Dubai',
  'Australia/Sydney',
  'Australia/Melbourne',
  'Pacific/Auckland',
  'Pacific/Honolulu',
  'UTC',
];

interface TimezoneSelectorProps {
  value: string;
  onChange: (timezone: string) => void;
  label?: string;
}

export function TimezoneSelector({ value, onChange, label = 'Timezone' }: TimezoneSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');

  const filteredTimezones = useMemo(() => {
    if (!search) return COMMON_TIMEZONES;
    const searchLower = search.toLowerCase();
    return COMMON_TIMEZONES.filter((tz) => 
      tz.toLowerCase().includes(searchLower)
    );
  }, [search]);

  const currentTimezoneDisplay = useMemo(() => {
    const cityName = value.split('/').pop()?.replace(/_/g, ' ') || value;
    return cityName;
  }, [value]);

  const handleSelect = (timezone: string) => {
    onChange(timezone);
    setIsOpen(false);
    setSearch('');
  };

  return (
    <div className="space-y-2" data-testid="timezone-selector">
      <Label className="text-sm text-muted-foreground flex items-center gap-2">
        <Globe className="h-4 w-4" />
        {label}
      </Label>

      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className="w-full justify-start text-left font-normal h-9"
            aria-label="Select timezone"
            data-testid="button-timezone"
          >
            <Globe className="h-4 w-4 mr-2 text-muted-foreground" />
            <span className="flex-1 truncate">{currentTimezoneDisplay}</span>
            <span className="text-xs text-muted-foreground ml-2">
              {formatTimezoneOffset(value)}
            </span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 p-0" align="start">
          <div className="p-2 border-b">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search timezones..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 h-8"
                aria-label="Search timezones"
                data-testid="input-timezone-search"
              />
            </div>
          </div>
          <ScrollArea className="h-64">
            <div className="p-1">
              {filteredTimezones.length === 0 ? (
                <div className="text-sm text-muted-foreground text-center py-4">
                  No timezones found
                </div>
              ) : (
                filteredTimezones.map((tz) => {
                  const isSelected = tz === value;
                  const cityName = tz.split('/').pop()?.replace(/_/g, ' ') || tz;
                  
                  return (
                    <button
                      key={tz}
                      onClick={() => handleSelect(tz)}
                      className={`
                        w-full flex items-center gap-2 px-2 py-1.5 text-sm rounded-md text-left
                        ${isSelected ? 'bg-primary/10 text-primary' : 'hover:bg-muted'}
                      `}
                      aria-selected={isSelected}
                      data-testid={`timezone-option-${tz.replace(/\//g, '-')}`}
                    >
                      {isSelected && <Check className="h-4 w-4 flex-shrink-0" />}
                      <span className={`flex-1 ${!isSelected && 'ml-6'}`}>{cityName}</span>
                      <span className="text-xs text-muted-foreground">
                        {formatTimezoneOffset(tz)}
                      </span>
                    </button>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </PopoverContent>
      </Popover>
    </div>
  );
}
