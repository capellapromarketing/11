import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DateTime } from 'luxon';
import { 
  X, 
  Trash2, 
  Pencil, 
  Clock, 
  MapPin, 
  Video, 
  RefreshCw, 
  Plane,
  Calendar as CalendarIcon,
  ExternalLink,
  Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { 
  parseEventDateTime, 
  convertToUserTimezone, 
  formatDateRange,
  isDifferentTimezone,
  formatTimezoneOffset
} from '../lib/dateUtils';
import { isRecurringEvent, getRecurrenceDescription } from '../lib/recurrence';
import { CALENDAR_COLORS } from '../types/calendar.types';

export function EventPopover() {
  const { 
    selectedEvent, 
    isEventPopoverOpen, 
    setIsEventPopoverOpen,
    setSelectedEvent,
    setIsCreateModalOpen,
    calendars,
    userTimezone,
  } = useCalendarStore();
  
  const { deleteEvent, isDeleting } = useCalendarData();

  const calendar = useMemo(() => 
    selectedEvent ? calendars.find((c) => c.id === selectedEvent.calendarId) : null,
    [calendars, selectedEvent]
  );

  const calendarColor = useMemo(() => {
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  }, [calendar]);

  const eventTimes = useMemo(() => {
    if (!selectedEvent) return null;
    const { start, end } = parseEventDateTime(selectedEvent);
    const localStart = convertToUserTimezone(start, userTimezone);
    const localEnd = convertToUserTimezone(end, userTimezone);
    return { start: localStart, end: localEnd };
  }, [selectedEvent, userTimezone]);

  const isFromDifferentTimezone = useMemo(() => 
    selectedEvent ? isDifferentTimezone(selectedEvent.timezone, userTimezone) : false,
    [selectedEvent, userTimezone]
  );

  const isRecurring = selectedEvent ? isRecurringEvent(selectedEvent) : false;

  const handleClose = () => {
    setIsEventPopoverOpen(false);
    setSelectedEvent(null);
  };

  const handleEdit = () => {
    setIsCreateModalOpen(true);
  };

  const handleDelete = () => {
    if (selectedEvent) {
      deleteEvent(selectedEvent.id);
      handleClose();
    }
  };

  if (!selectedEvent || !eventTimes) return null;

  return (
    <AnimatePresence>
      {isEventPopoverOpen && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -10 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-50 flex items-start justify-center pt-20"
          onClick={handleClose}
        >
          <div 
            className="absolute inset-0 bg-black/20" 
            aria-hidden="true"
          />
          <motion.div
            className="relative w-[280px] bg-popover border rounded-lg shadow-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label={`Event details: ${selectedEvent.title}`}
            data-testid="event-popover"
          >
            <div 
              className="h-2"
              style={{ backgroundColor: calendarColor }}
            />

            <div className="p-4">
              <div className="flex items-start justify-between gap-2 mb-3">
                <h3 className="font-semibold text-lg leading-tight">
                  {selectedEvent.title}
                </h3>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 -mt-1 -mr-1"
                  onClick={handleClose}
                  aria-label="Close popover"
                  data-testid="button-close-popover"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-4 w-4 flex-shrink-0" />
                  <span>
                    {selectedEvent.isAllDay 
                      ? eventTimes.start.toFormat('EEEE, MMMM d, yyyy')
                      : formatDateRange(eventTimes.start, eventTimes.end)
                    }
                  </span>
                </div>

                {isFromDifferentTimezone && (
                  <div className="flex items-center gap-2 text-orange-500">
                    <CalendarIcon className="h-4 w-4 flex-shrink-0" />
                    <span className="text-xs">
                      Original: {formatTimezoneOffset(selectedEvent.timezone)}
                    </span>
                  </div>
                )}

                {selectedEvent.location && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span className="truncate">{selectedEvent.location}</span>
                  </div>
                )}

                {selectedEvent.videoCall && (
                  <a
                    href={selectedEvent.videoCall.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-primary hover:underline"
                  >
                    <Video className="h-4 w-4 flex-shrink-0" />
                    <span>Join {selectedEvent.videoCall.provider} call</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}

                {isRecurring && selectedEvent.recurrence && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <RefreshCw className="h-4 w-4 flex-shrink-0" />
                    <span>{getRecurrenceDescription(selectedEvent.recurrence)}</span>
                  </div>
                )}

                {selectedEvent.travelTime && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Plane className="h-4 w-4 flex-shrink-0" />
                    <span>{selectedEvent.travelTime.minutes} min travel time</span>
                  </div>
                )}

                {selectedEvent.attendees && selectedEvent.attendees.length > 0 && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Users className="h-4 w-4 flex-shrink-0" />
                    <span>{selectedEvent.attendees.length} attendees</span>
                  </div>
                )}

                {selectedEvent.description && (
                  <p className="text-muted-foreground pt-2 border-t mt-3">
                    {selectedEvent.description}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 mt-4 pt-3 border-t">
                <div className="flex-1">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: calendarColor }}
                    title={calendar?.name}
                  />
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleEdit}
                  aria-label="Edit event"
                  data-testid="button-edit-event"
                >
                  <Pencil className="h-4 w-4 mr-1" />
                  Edit
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDelete}
                  disabled={isDeleting}
                  className="text-destructive hover:text-destructive"
                  aria-label="Delete event"
                  data-testid="button-delete-event"
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
