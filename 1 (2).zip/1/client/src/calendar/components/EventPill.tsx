import { useMemo } from 'react';
import { useDraggable } from '@dnd-kit/core';
import { motion } from 'framer-motion';
import { Video, RefreshCw, Plane, MapPin, Clock } from 'lucide-react';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { parseEventDateTime, convertToUserTimezone, isDifferentTimezone } from '../lib/dateUtils';
import { isRecurringEvent } from '../lib/recurrence';
import { CALENDAR_COLORS, type CalendarEvent } from '../types/calendar.types';

interface EventPillProps {
  event: CalendarEvent;
  compact?: boolean;
  showTime?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
  className?: string;
}

export function EventPill({ 
  event, 
  compact = false, 
  showTime = true, 
  onClick,
  style,
  className = ''
}: EventPillProps) {
  const { userTimezone, calendars, setSelectedEvent } = useCalendarStore();
  
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: event.id,
    data: { type: 'event', event },
  });

  const calendar = useMemo(() => 
    calendars.find((c) => c.id === event.calendarId),
    [calendars, event.calendarId]
  );

  const calendarColor = useMemo(() => {
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  }, [calendar]);

  const { start, end } = useMemo(() => parseEventDateTime(event), [event]);
  
  const localStart = useMemo(() => 
    convertToUserTimezone(start, userTimezone),
    [start, userTimezone]
  );

  const isFromDifferentTimezone = useMemo(() => 
    isDifferentTimezone(event.timezone, userTimezone),
    [event.timezone, userTimezone]
  );

  const hasVideo = !!event.videoCall;
  const hasTravel = !!event.travelTime;
  const isRecurring = isRecurringEvent(event);

  const handleClick = () => {
    setSelectedEvent(event);
    onClick?.();
  };

  const dragStyle = transform
    ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` }
    : undefined;

  return (
    <motion.div
      ref={setNodeRef}
      style={{ ...style, ...dragStyle }}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      className={`
        relative flex items-center gap-1.5 px-2 rounded-md cursor-pointer
        ${compact ? 'min-h-[20px] py-0.5' : 'min-h-[24px] py-1'}
        ${isDragging ? 'opacity-50 shadow-lg z-50' : 'hover-elevate active-elevate-2'}
        ${event.isAllDay ? 'bg-opacity-90' : ''}
        ${className}
      `}
      onClick={handleClick}
      {...attributes}
      {...listeners}
      role="button"
      aria-label={`Event: ${event.title}`}
      data-testid={`event-pill-${event.id}`}
    >
      <div
        className="absolute left-0 top-0 bottom-0 w-[3px] rounded-l-md"
        style={{ backgroundColor: calendarColor }}
      />

      {isFromDifferentTimezone && (
        <div
          className="absolute right-0 top-0 bottom-0 w-[2px] bg-gradient-to-b from-orange-400 to-orange-600 rounded-r-md"
          title={`Event timezone: ${event.timezone}`}
        />
      )}

      <div 
        className="flex-1 min-w-0 flex items-center gap-1.5 pl-1"
        style={{ 
          backgroundColor: `${calendarColor}15`,
        }}
      >
        {showTime && !event.isAllDay && !compact && (
          <span className="text-xs text-muted-foreground flex-shrink-0">
            {localStart.toFormat('h:mm a')}
          </span>
        )}

        <span className={`truncate ${compact ? 'text-xs' : 'text-sm'} font-medium`}>
          {event.title}
        </span>

        <div className="flex items-center gap-1 flex-shrink-0 ml-auto">
          {hasVideo && (
            <Video 
              className="h-3 w-3 text-primary" 
              aria-label="Video call"
            />
          )}
          {isRecurring && (
            <RefreshCw 
              className="h-3 w-3 text-muted-foreground" 
              aria-label="Recurring event"
            />
          )}
          {hasTravel && (
            <Plane 
              className="h-3 w-3 text-muted-foreground" 
              aria-label={`${event.travelTime?.minutes} min travel time`}
            />
          )}
        </div>
      </div>
    </motion.div>
  );
}
