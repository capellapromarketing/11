import { DateTime } from 'luxon';
import type { ParsedEvent, DailyPlan, CalendarEvent, SuggestedEvent, SuggestedBlock, Priority } from '../types/calendar.types';

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function parseNaturalLanguageEvent(input: string): Promise<ParsedEvent> {
  await delay(500 + Math.random() * 500);

  const lowerInput = input.toLowerCase();
  const now = DateTime.now();
  let parsedDate = now;
  let parsedTime = { hour: 9, minute: 0 };
  let duration = 60;
  let isAllDay = false;
  let confidence = 0.7;
  
  if (lowerInput.includes('tomorrow')) {
    parsedDate = now.plus({ days: 1 });
    confidence += 0.1;
  } else if (lowerInput.includes('next week')) {
    parsedDate = now.plus({ weeks: 1 });
    confidence += 0.05;
  } else if (lowerInput.includes('today')) {
    parsedDate = now;
    confidence += 0.1;
  }
  
  const timeMatch = lowerInput.match(/at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
  if (timeMatch) {
    let hour = parseInt(timeMatch[1], 10);
    const minute = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
    const meridiem = timeMatch[3]?.toLowerCase();
    
    if (meridiem === 'pm' && hour < 12) hour += 12;
    if (meridiem === 'am' && hour === 12) hour = 0;
    
    parsedTime = { hour, minute };
    confidence += 0.15;
  } else if (lowerInput.includes('morning')) {
    parsedTime = { hour: 9, minute: 0 };
    confidence += 0.05;
  } else if (lowerInput.includes('afternoon')) {
    parsedTime = { hour: 14, minute: 0 };
    confidence += 0.05;
  } else if (lowerInput.includes('evening')) {
    parsedTime = { hour: 18, minute: 0 };
    confidence += 0.05;
  }
  
  if (lowerInput.includes('30 min')) {
    duration = 30;
    confidence += 0.1;
  } else if (lowerInput.includes('1 hour') || lowerInput.includes('an hour')) {
    duration = 60;
    confidence += 0.1;
  } else if (lowerInput.includes('2 hour')) {
    duration = 120;
    confidence += 0.1;
  } else if (lowerInput.includes('all day')) {
    isAllDay = true;
    confidence += 0.1;
  }
  
  let title = input
    .replace(/tomorrow|today|next week/gi, '')
    .replace(/at \d{1,2}(?::\d{2})?\s*(am|pm)?/gi, '')
    .replace(/in the (morning|afternoon|evening)/gi, '')
    .replace(/for \d+ (min|hour)s?/gi, '')
    .replace(/all day/gi, '')
    .trim();
  
  if (title.startsWith('meeting with')) {
    title = title.charAt(0).toUpperCase() + title.slice(1);
    confidence += 0.1;
  }
  
  const startTime = parsedDate.set(parsedTime);
  const endTime = startTime.plus({ minutes: duration });

  return {
    title: title || 'New Event',
    startTime: startTime.toISO() || undefined,
    endTime: endTime.toISO() || undefined,
    date: parsedDate.toISODate() || undefined,
    duration,
    isAllDay,
    confidence: Math.min(confidence, 0.98),
  };
}

export async function generateDailyPlan(userId: string, date: DateTime): Promise<DailyPlan> {
  await delay(1500 + Math.random() * 1000);

  const suggestedEvents: SuggestedEvent[] = [
    {
      id: 'sug-1',
      title: 'Morning Focus Block',
      startTime: date.set({ hour: 9, minute: 0 }).toISO() || '',
      endTime: date.set({ hour: 11, minute: 0 }).toISO() || '',
      reason: 'Your most productive hours based on past patterns',
      priority: 'high',
    },
    {
      id: 'sug-2',
      title: 'Catch-up on Emails',
      startTime: date.set({ hour: 11, minute: 30 }).toISO() || '',
      endTime: date.set({ hour: 12, minute: 0 }).toISO() || '',
      reason: 'Good time to batch process communications',
      priority: 'medium',
    },
    {
      id: 'sug-3',
      title: 'Afternoon Deep Work',
      startTime: date.set({ hour: 14, minute: 0 }).toISO() || '',
      endTime: date.set({ hour: 16, minute: 0 }).toISO() || '',
      reason: 'Second productivity peak detected in your schedule',
      priority: 'high',
    },
  ];

  const suggestedBlocks: SuggestedBlock[] = [
    {
      id: 'block-1',
      type: 'buffer',
      startTime: date.set({ hour: 8, minute: 30 }).toISO() || '',
      endTime: date.set({ hour: 9, minute: 0 }).toISO() || '',
      label: 'Morning prep',
    },
    {
      id: 'block-2',
      type: 'break',
      startTime: date.set({ hour: 12, minute: 0 }).toISO() || '',
      endTime: date.set({ hour: 13, minute: 0 }).toISO() || '',
      label: 'Lunch break',
    },
    {
      id: 'block-3',
      type: 'break',
      startTime: date.set({ hour: 15, minute: 0 }).toISO() || '',
      endTime: date.set({ hour: 15, minute: 15 }).toISO() || '',
      label: 'Short break',
    },
  ];

  const priorities: Priority[] = [
    {
      id: 'pri-1',
      title: 'Complete Q4 Report',
      description: 'High priority task due this week',
      timeEstimate: 120,
    },
    {
      id: 'pri-2',
      title: 'Review PR #456',
      description: 'Team is waiting on this review',
      timeEstimate: 45,
    },
    {
      id: 'pri-3',
      title: 'Prepare for client meeting',
      description: 'Tomorrow\'s meeting needs prep work',
      timeEstimate: 60,
    },
  ];

  return {
    date: date.toISODate() || '',
    suggestedEvents,
    suggestedBlocks,
    priorities,
    summary: `Based on your schedule, today looks busy with ${3} existing meetings. I've identified ${priorities.length} priorities and suggested optimal time blocks for focused work. Your most productive hours are typically 9-11 AM.`,
  };
}

export async function syncTaskToCalendar(taskId: string): Promise<CalendarEvent> {
  await delay(300 + Math.random() * 300);

  const now = DateTime.now();
  const startTime = now.plus({ hours: 2 }).set({ minute: 0 });
  const endTime = startTime.plus({ hours: 1 });

  return {
    id: `evt-from-task-${taskId}-${Date.now()}`,
    title: 'Task converted to event',
    description: 'This task was converted to a calendar event',
    startTime: startTime.toISO() || '',
    endTime: endTime.toISO() || '',
    timezone: now.zoneName || 'America/New_York',
    isAllDay: false,
    calendarId: 'cal-tasks',
  };
}
