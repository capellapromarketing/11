import { useState, useCallback } from 'react';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from './useCalendarData';
import { 
  updateSingleOccurrence, 
  updateThisAndFollowing,
  getRecurrenceDescription,
  isRecurringEvent,
} from '../lib/recurrence';
import type { 
  CalendarEvent, 
  RecurrenceRule, 
  RecurrenceFrequency, 
  RecurrenceEditMode 
} from '../types/calendar.types';

interface RecurrenceEditState {
  isOpen: boolean;
  event: CalendarEvent | null;
  occurrenceDate: DateTime | null;
  pendingUpdates: Partial<CalendarEvent> | null;
}

export function useRecurrence() {
  const { events, updateEvent: storeUpdateEvent, addEvent, deleteEvent } = useCalendarStore();
  const { updateEvent } = useCalendarData();

  const [editState, setEditState] = useState<RecurrenceEditState>({
    isOpen: false,
    event: null,
    occurrenceDate: null,
    pendingUpdates: null,
  });

  const [selectedFrequency, setSelectedFrequency] = useState<RecurrenceFrequency>('weekly');
  const [selectedInterval, setSelectedInterval] = useState(1);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [hasEndDate, setHasEndDate] = useState(false);
  const [endDate, setEndDate] = useState<DateTime | null>(null);
  const [repeatCount, setRepeatCount] = useState<number | null>(null);

  const buildRecurrenceRule = useCallback((): RecurrenceRule => {
    const rule: RecurrenceRule = {
      frequency: selectedFrequency,
      interval: selectedInterval,
    };

    if (selectedFrequency === 'weekly' && selectedDays.length > 0) {
      rule.byDay = selectedDays;
    }

    if (hasEndDate && endDate) {
      rule.until = endDate.toISO() || undefined;
    } else if (repeatCount) {
      rule.count = repeatCount;
    }

    return rule;
  }, [selectedFrequency, selectedInterval, selectedDays, hasEndDate, endDate, repeatCount]);

  const openEditModeDialog = useCallback((
    event: CalendarEvent,
    occurrenceDate: DateTime,
    updates: Partial<CalendarEvent>
  ) => {
    setEditState({
      isOpen: true,
      event,
      occurrenceDate,
      pendingUpdates: updates,
    });
  }, []);

  const closeEditModeDialog = useCallback(() => {
    setEditState({
      isOpen: false,
      event: null,
      occurrenceDate: null,
      pendingUpdates: null,
    });
  }, []);

  const handleEditModeSelection = useCallback((mode: RecurrenceEditMode) => {
    const { event, occurrenceDate, pendingUpdates } = editState;
    
    if (!event || !occurrenceDate || !pendingUpdates) {
      closeEditModeDialog();
      return;
    }

    const originalEvent = events.find((e) => 
      e.id === event.recurrenceId || e.id === event.id
    );

    if (!originalEvent) {
      closeEditModeDialog();
      return;
    }

    if (mode === 'single') {
      const exceptionEvent = updateSingleOccurrence(
        originalEvent,
        occurrenceDate,
        pendingUpdates
      );
      addEvent(exceptionEvent);
    } else if (mode === 'thisAndFollowing') {
      const { updatedOriginal, newSeries } = updateThisAndFollowing(
        originalEvent,
        occurrenceDate,
        pendingUpdates
      );
      
      storeUpdateEvent(originalEvent.id, updatedOriginal);
      addEvent(newSeries);
    }

    closeEditModeDialog();
  }, [editState, events, addEvent, storeUpdateEvent, closeEditModeDialog]);

  const handleDeleteRecurring = useCallback((
    event: CalendarEvent,
    mode: RecurrenceEditMode,
    occurrenceDate: DateTime
  ) => {
    const originalEvent = events.find((e) => 
      e.id === event.recurrenceId || e.id === event.id
    );

    if (!originalEvent) return;

    if (mode === 'single') {
      const exceptionEvent: CalendarEvent = {
        ...originalEvent,
        id: `${originalEvent.id}-deleted-${occurrenceDate.toISODate()}`,
        recurrence: undefined,
        recurrenceId: originalEvent.id,
        isRecurrenceException: true,
        title: '[DELETED]',
      };
      addEvent(exceptionEvent);
    } else if (mode === 'thisAndFollowing') {
      storeUpdateEvent(originalEvent.id, {
        recurrence: originalEvent.recurrence
          ? {
              ...originalEvent.recurrence,
              until: occurrenceDate.minus({ days: 1 }).toISO() || undefined,
            }
          : undefined,
      });
    }
  }, [events, addEvent, storeUpdateEvent]);

  const resetRecurrenceForm = useCallback(() => {
    setSelectedFrequency('weekly');
    setSelectedInterval(1);
    setSelectedDays([]);
    setHasEndDate(false);
    setEndDate(null);
    setRepeatCount(null);
  }, []);

  const initializeFromEvent = useCallback((event: CalendarEvent) => {
    if (!event.recurrence) {
      resetRecurrenceForm();
      return;
    }

    const { recurrence } = event;
    setSelectedFrequency(recurrence.frequency);
    setSelectedInterval(recurrence.interval);
    
    if (recurrence.byDay) {
      setSelectedDays(recurrence.byDay);
    }
    
    if (recurrence.until) {
      setHasEndDate(true);
      setEndDate(DateTime.fromISO(recurrence.until));
    } else if (recurrence.count) {
      setRepeatCount(recurrence.count);
    }
  }, [resetRecurrenceForm]);

  return {
    editState,
    selectedFrequency,
    selectedInterval,
    selectedDays,
    hasEndDate,
    endDate,
    repeatCount,
    setSelectedFrequency,
    setSelectedInterval,
    setSelectedDays,
    setHasEndDate,
    setEndDate,
    setRepeatCount,
    buildRecurrenceRule,
    openEditModeDialog,
    closeEditModeDialog,
    handleEditModeSelection,
    handleDeleteRecurring,
    resetRecurrenceForm,
    initializeFromEvent,
    getRecurrenceDescription,
    isRecurringEvent,
  };
}
