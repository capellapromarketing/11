import { useEffect, useCallback } from 'react';
import { useCalendarStore } from '../store/calendarStore';

interface KeyboardShortcutHandlers {
  onOpenNLInput?: () => void;
  onCreateEvent?: () => void;
  onNavigatePrevious?: () => void;
  onNavigateNext?: () => void;
  onGoToToday?: () => void;
  onSwitchToMonth?: () => void;
  onSwitchToWeek?: () => void;
  onSwitchToDay?: () => void;
  onSwitchToAgenda?: () => void;
  onToggleSidebar?: () => void;
  onEscape?: () => void;
  onDelete?: () => void;
  onUndo?: () => void;
}

export function useKeyboardShortcuts(handlers: KeyboardShortcutHandlers = {}) {
  const {
    setIsCreateModalOpen,
    setIsEventPopoverOpen,
    setIsAIPanelOpen,
    setCurrentView,
    goToPrevious,
    goToNext,
    goToToday,
    isSidebarOpen,
    setIsSidebarOpen,
    selectedEvent,
    setSelectedEvent,
    popFromUndoStack,
    addEvent,
  } = useCalendarStore();

  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    const target = event.target as HTMLElement;
    const isInputFocused = 
      target.tagName === 'INPUT' || 
      target.tagName === 'TEXTAREA' || 
      target.isContentEditable;

    if (event.key === 'k' && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      handlers.onOpenNLInput?.();
      return;
    }

    if (event.key === 'Escape') {
      event.preventDefault();
      setIsEventPopoverOpen(false);
      setSelectedEvent(null);
      handlers.onEscape?.();
      return;
    }

    if (isInputFocused) return;

    if (event.key === 'c' && !event.metaKey && !event.ctrlKey) {
      event.preventDefault();
      setIsCreateModalOpen(true);
      handlers.onCreateEvent?.();
      return;
    }

    if (event.key === 'ArrowLeft' && !event.shiftKey) {
      event.preventDefault();
      goToPrevious();
      handlers.onNavigatePrevious?.();
      return;
    }

    if (event.key === 'ArrowRight' && !event.shiftKey) {
      event.preventDefault();
      goToNext();
      handlers.onNavigateNext?.();
      return;
    }

    if (event.key === 't' && !event.metaKey && !event.ctrlKey) {
      event.preventDefault();
      goToToday();
      handlers.onGoToToday?.();
      return;
    }

    if (event.key === 'm' && !event.metaKey && !event.ctrlKey) {
      event.preventDefault();
      setCurrentView('month');
      handlers.onSwitchToMonth?.();
      return;
    }

    if (event.key === 'w' && !event.metaKey && !event.ctrlKey) {
      event.preventDefault();
      setCurrentView('week');
      handlers.onSwitchToWeek?.();
      return;
    }

    if (event.key === 'd' && !event.metaKey && !event.ctrlKey) {
      event.preventDefault();
      setCurrentView('day');
      handlers.onSwitchToDay?.();
      return;
    }

    if (event.key === 'a' && !event.metaKey && !event.ctrlKey) {
      event.preventDefault();
      setCurrentView('agenda');
      handlers.onSwitchToAgenda?.();
      return;
    }

    if (event.key === '[' || event.key === ']') {
      event.preventDefault();
      setIsSidebarOpen(!isSidebarOpen);
      handlers.onToggleSidebar?.();
      return;
    }

    if ((event.key === 'Delete' || event.key === 'Backspace') && selectedEvent) {
      event.preventDefault();
      handlers.onDelete?.();
      return;
    }

    if (event.key === 'z' && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      const undoneEvent = popFromUndoStack();
      if (undoneEvent) {
        addEvent(undoneEvent);
        handlers.onUndo?.();
      }
      return;
    }
  }, [
    handlers,
    setIsCreateModalOpen,
    setIsEventPopoverOpen,
    setIsAIPanelOpen,
    setCurrentView,
    goToPrevious,
    goToNext,
    goToToday,
    isSidebarOpen,
    setIsSidebarOpen,
    selectedEvent,
    setSelectedEvent,
    popFromUndoStack,
    addEvent,
  ]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);

  return {
    shortcuts: [
      { key: 'Cmd/Ctrl + K', description: 'Open natural language input' },
      { key: 'C', description: 'Create new event' },
      { key: 'T', description: 'Go to today' },
      { key: '←', description: 'Navigate to previous period' },
      { key: '→', description: 'Navigate to next period' },
      { key: 'M', description: 'Switch to month view' },
      { key: 'W', description: 'Switch to week view' },
      { key: 'D', description: 'Switch to day view' },
      { key: 'A', description: 'Switch to agenda view' },
      { key: '[ / ]', description: 'Toggle sidebar' },
      { key: 'Escape', description: 'Close popover/modal' },
      { key: 'Delete', description: 'Delete selected event' },
      { key: 'Cmd/Ctrl + Z', description: 'Undo last action' },
    ],
  };
}
