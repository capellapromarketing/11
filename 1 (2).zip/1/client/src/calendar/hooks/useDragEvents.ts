import { useState, useCallback } from 'react';
import { DateTime } from 'luxon';
import type { DragStartEvent, DragEndEvent, DragMoveEvent } from '@dnd-kit/core';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from './useCalendarData';
import { snapToGrid, parseEventDateTime } from '../lib/dateUtils';
import type { CalendarEvent, Task } from '../types/calendar.types';

interface DragState {
  activeId: string | null;
  activeType: 'event' | 'task' | null;
  originalEvent: CalendarEvent | null;
  originalTask: Task | null;
  previewStart: DateTime | null;
  previewEnd: DateTime | null;
}

export function useDragEvents() {
  const { 
    events, 
    tasks,
    userTimezone,
    setIsDragging,
    setDraggedEventId,
    moveEventToDate,
    convertTaskToEvent,
  } = useCalendarStore();
  
  const { updateEvent } = useCalendarData();

  const [dragState, setDragState] = useState<DragState>({
    activeId: null,
    activeType: null,
    originalEvent: null,
    originalTask: null,
    previewStart: null,
    previewEnd: null,
  });

  const handleDragStart = useCallback((event: DragStartEvent) => {
    const { active } = event;
    const activeId = active.id as string;
    
    setIsDragging(true);
    setDraggedEventId(activeId);

    const isTask = activeId.startsWith('task-');
    
    if (isTask) {
      const task = tasks.find((t) => t.id === activeId);
      setDragState({
        activeId,
        activeType: 'task',
        originalEvent: null,
        originalTask: task || null,
        previewStart: null,
        previewEnd: null,
      });
    } else {
      const calendarEvent = events.find((e) => e.id === activeId);
      setDragState({
        activeId,
        activeType: 'event',
        originalEvent: calendarEvent || null,
        originalTask: null,
        previewStart: null,
        previewEnd: null,
      });
    }
  }, [events, tasks, setIsDragging, setDraggedEventId]);

  const handleDragMove = useCallback((event: DragMoveEvent) => {
    const { over, delta } = event;
    
    if (!over || !dragState.activeId) return;

    const dropData = over.data.current as { date?: DateTime; hour?: number; minute?: number } | undefined;
    if (!dropData?.date) return;

    let newStart: DateTime;
    
    if (dropData.hour !== undefined) {
      newStart = dropData.date.set({ 
        hour: dropData.hour, 
        minute: dropData.minute || 0 
      });
    } else {
      newStart = dropData.date.startOf('day').set({ hour: 9, minute: 0 });
    }

    newStart = snapToGrid(newStart, 15);

    let duration = 60;
    if (dragState.originalEvent) {
      const { start, end } = parseEventDateTime(dragState.originalEvent);
      duration = end.diff(start, 'minutes').minutes;
    }

    const newEnd = newStart.plus({ minutes: duration });

    setDragState((prev) => ({
      ...prev,
      previewStart: newStart,
      previewEnd: newEnd,
    }));
  }, [dragState.activeId, dragState.originalEvent]);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    
    setIsDragging(false);
    setDraggedEventId(null);

    if (!over) {
      setDragState({
        activeId: null,
        activeType: null,
        originalEvent: null,
        originalTask: null,
        previewStart: null,
        previewEnd: null,
      });
      return;
    }

    const dropData = over.data.current as { date?: DateTime; hour?: number; minute?: number } | undefined;
    if (!dropData?.date) {
      setDragState({
        activeId: null,
        activeType: null,
        originalEvent: null,
        originalTask: null,
        previewStart: null,
        previewEnd: null,
      });
      return;
    }

    const activeId = active.id as string;
    let newStart: DateTime;

    if (dropData.hour !== undefined) {
      newStart = dropData.date.set({ 
        hour: dropData.hour, 
        minute: dropData.minute || 0 
      });
    } else {
      newStart = dropData.date.startOf('day').set({ hour: 9, minute: 0 });
    }

    newStart = snapToGrid(newStart, 15);

    if (dragState.activeType === 'task' && dragState.originalTask) {
      const newEnd = newStart.plus({ hours: 1 });
      convertTaskToEvent(activeId, newStart, newEnd);
    } else if (dragState.activeType === 'event' && dragState.originalEvent) {
      const { start, end } = parseEventDateTime(dragState.originalEvent);
      const duration = end.diff(start, 'minutes').minutes;
      const newEnd = newStart.plus({ minutes: duration });
      
      moveEventToDate(activeId, newStart, newEnd);
    }

    setDragState({
      activeId: null,
      activeType: null,
      originalEvent: null,
      originalTask: null,
      previewStart: null,
      previewEnd: null,
    });
  }, [dragState, setIsDragging, setDraggedEventId, moveEventToDate, convertTaskToEvent]);

  const handleDragCancel = useCallback(() => {
    setIsDragging(false);
    setDraggedEventId(null);
    setDragState({
      activeId: null,
      activeType: null,
      originalEvent: null,
      originalTask: null,
      previewStart: null,
      previewEnd: null,
    });
  }, [setIsDragging, setDraggedEventId]);

  return {
    dragState,
    handleDragStart,
    handleDragMove,
    handleDragEnd,
    handleDragCancel,
    isDragging: dragState.activeId !== null,
    activeId: dragState.activeId,
    activeType: dragState.activeType,
    previewStart: dragState.previewStart,
    previewEnd: dragState.previewEnd,
  };
}
