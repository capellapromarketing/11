import { useState, useCallback, useRef, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { DateTime } from 'luxon';
import { parseNaturalLanguageEvent } from '../mocks/fetchers';
import { useCalendarStore } from '../store/calendarStore';
import type { ParsedEvent, CalendarEvent } from '../types/calendar.types';

export function useNLPInput() {
  const { 
    nlInputValue, 
    setNLInputValue, 
    parsedEvent, 
    setParsedEvent,
    setIsCreateModalOpen,
    addEvent,
    userTimezone,
    calendars,
  } = useCalendarStore();
  
  const [isInputFocused, setIsInputFocused] = useState(false);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const parseMutation = useMutation({
    mutationFn: parseNaturalLanguageEvent,
    onSuccess: (result) => {
      setParsedEvent(result);
    },
    onError: () => {
      setParsedEvent(null);
    },
  });

  const handleInputChange = useCallback((value: string) => {
    setNLInputValue(value);

    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    if (value.trim().length >= 3) {
      debounceRef.current = setTimeout(() => {
        parseMutation.mutate(value);
      }, 300);
    } else {
      setParsedEvent(null);
    }
  }, [setNLInputValue, setParsedEvent, parseMutation]);

  const handleClear = useCallback(() => {
    setNLInputValue('');
    setParsedEvent(null);
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
  }, [setNLInputValue, setParsedEvent]);

  const handleSubmit = useCallback(() => {
    if (!parsedEvent || !parsedEvent.startTime || !parsedEvent.endTime) {
      setIsCreateModalOpen(true);
      return;
    }

    const defaultCalendar = calendars.find((c) => c.isDefault) || calendars[0];
    
    const newEvent: CalendarEvent = {
      id: `evt-${Date.now()}`,
      title: parsedEvent.title,
      startTime: parsedEvent.startTime,
      endTime: parsedEvent.endTime,
      timezone: userTimezone,
      isAllDay: parsedEvent.isAllDay || false,
      calendarId: defaultCalendar?.id || 'cal-work',
      location: parsedEvent.location,
    };

    addEvent(newEvent);
    handleClear();
  }, [parsedEvent, calendars, userTimezone, addEvent, handleClear, setIsCreateModalOpen]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      handleClear();
      inputRef.current?.blur();
    } else if (e.key === 'Enter' && parsedEvent) {
      e.preventDefault();
      handleSubmit();
    }
  }, [handleClear, handleSubmit, parsedEvent]);

  const focusInput = useCallback(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, []);

  return {
    inputValue: nlInputValue,
    parsedEvent,
    isLoading: parseMutation.isPending,
    isInputFocused,
    inputRef,
    handleInputChange,
    handleClear,
    handleSubmit,
    handleKeyDown,
    setIsInputFocused,
    focusInput,
  };
}
