import { create } from 'zustand';
import { DateTime } from 'luxon';
import type { CalendarStore, CalendarEvent, Task, Calendar, ParsedEvent, DailyPlan } from '../types/calendar.types';
import mockData from '../mock-data/calendar.mock.json';

const initialCalendars: Calendar[] = mockData.calendars as Calendar[];
const initialEvents: CalendarEvent[] = mockData.events as CalendarEvent[];
const initialTasks: Task[] = mockData.tasks as Task[];

export const useCalendarStore = create<CalendarStore>((set, get) => ({
  currentDate: DateTime.now(),
  currentView: 'week',
  selectedDate: null,
  selectedEvent: null,
  calendars: initialCalendars,
  events: initialEvents,
  tasks: initialTasks,
  isCreateModalOpen: false,
  isEventPopoverOpen: false,
  isAIPanelOpen: false,
  isAIConsentModalOpen: false,
  isSidebarOpen: true,
  userTimezone: DateTime.local().zoneName || 'America/New_York',
  nlInputValue: '',
  parsedEvent: null,
  dailyPlan: null,
  isDragging: false,
  draggedEventId: null,
  undoStack: [],

  setCurrentDate: (date) => set({ currentDate: date }),
  setCurrentView: (view) => set({ currentView: view }),
  setSelectedDate: (date) => set({ selectedDate: date }),
  setSelectedEvent: (event) => set({ selectedEvent: event, isEventPopoverOpen: !!event }),
  
  toggleCalendarVisibility: (calendarId) =>
    set((state) => ({
      calendars: state.calendars.map((cal) =>
        cal.id === calendarId ? { ...cal, isVisible: !cal.isVisible } : cal
      ),
    })),

  addEvent: (event) =>
    set((state) => ({
      events: [...state.events, event],
    })),

  updateEvent: (eventId, updates) =>
    set((state) => ({
      events: state.events.map((evt) =>
        evt.id === eventId ? { ...evt, ...updates } : evt
      ),
    })),

  deleteEvent: (eventId) =>
    set((state) => ({
      events: state.events.filter((evt) => evt.id !== eventId),
      selectedEvent: state.selectedEvent?.id === eventId ? null : state.selectedEvent,
      isEventPopoverOpen: state.selectedEvent?.id === eventId ? false : state.isEventPopoverOpen,
    })),

  addTask: (task) =>
    set((state) => ({
      tasks: [...state.tasks, task],
    })),

  updateTask: (taskId, updates) =>
    set((state) => ({
      tasks: state.tasks.map((task) =>
        task.id === taskId ? { ...task, ...updates } : task
      ),
    })),

  deleteTask: (taskId) =>
    set((state) => ({
      tasks: state.tasks.filter((task) => task.id !== taskId),
    })),

  toggleTaskComplete: (taskId) =>
    set((state) => ({
      tasks: state.tasks.map((task) =>
        task.id === taskId ? { ...task, isCompleted: !task.isCompleted } : task
      ),
    })),

  setIsCreateModalOpen: (isOpen) => set({ isCreateModalOpen: isOpen }),
  setIsEventPopoverOpen: (isOpen) => set({ isEventPopoverOpen: isOpen }),
  setIsAIPanelOpen: (isOpen) => set({ isAIPanelOpen: isOpen }),
  setIsAIConsentModalOpen: (isOpen) => set({ isAIConsentModalOpen: isOpen }),
  setIsSidebarOpen: (isOpen) => set({ isSidebarOpen: isOpen }),
  setNLInputValue: (value) => set({ nlInputValue: value }),
  setParsedEvent: (event) => set({ parsedEvent: event }),
  setDailyPlan: (plan) => set({ dailyPlan: plan }),
  setIsDragging: (isDragging) => set({ isDragging }),
  setDraggedEventId: (eventId) => set({ draggedEventId: eventId }),

  pushToUndoStack: (event) =>
    set((state) => ({
      undoStack: [...state.undoStack, event],
    })),

  popFromUndoStack: () => {
    const state = get();
    if (state.undoStack.length === 0) return undefined;
    const lastEvent = state.undoStack[state.undoStack.length - 1];
    set({ undoStack: state.undoStack.slice(0, -1) });
    return lastEvent;
  },

  goToToday: () => set({ currentDate: DateTime.now() }),

  goToPrevious: () =>
    set((state) => {
      const { currentView, currentDate } = state;
      let newDate: DateTime;
      switch (currentView) {
        case 'month':
          newDate = currentDate.minus({ months: 1 });
          break;
        case 'week':
          newDate = currentDate.minus({ weeks: 1 });
          break;
        case 'day':
          newDate = currentDate.minus({ days: 1 });
          break;
        case 'agenda':
          newDate = currentDate.minus({ weeks: 1 });
          break;
        default:
          newDate = currentDate;
      }
      return { currentDate: newDate };
    }),

  goToNext: () =>
    set((state) => {
      const { currentView, currentDate } = state;
      let newDate: DateTime;
      switch (currentView) {
        case 'month':
          newDate = currentDate.plus({ months: 1 });
          break;
        case 'week':
          newDate = currentDate.plus({ weeks: 1 });
          break;
        case 'day':
          newDate = currentDate.plus({ days: 1 });
          break;
        case 'agenda':
          newDate = currentDate.plus({ weeks: 1 });
          break;
        default:
          newDate = currentDate;
      }
      return { currentDate: newDate };
    }),

  moveEventToDate: (eventId, newStart, newEnd) =>
    set((state) => {
      const event = state.events.find((e) => e.id === eventId);
      if (event) {
        state.pushToUndoStack(event);
      }
      return {
        events: state.events.map((evt) =>
          evt.id === eventId
            ? {
                ...evt,
                startTime: newStart.toISO() || evt.startTime,
                endTime: newEnd.toISO() || evt.endTime,
              }
            : evt
        ),
      };
    }),

  convertTaskToEvent: (taskId, startTime, endTime) =>
    set((state) => {
      const task = state.tasks.find((t) => t.id === taskId);
      if (!task) return state;

      const newEvent: CalendarEvent = {
        id: `evt-from-task-${taskId}`,
        title: task.title,
        description: task.description,
        startTime: startTime.toISO() || '',
        endTime: endTime.toISO() || '',
        timezone: state.userTimezone,
        isAllDay: false,
        calendarId: task.calendarId,
      };

      return {
        events: [...state.events, newEvent],
        tasks: state.tasks.filter((t) => t.id !== taskId),
      };
    }),
}));
