import { useEffect, useMemo, useCallback } from 'react';
import { DndContext, DragEndEvent, DragStartEvent, DragMoveEvent, closestCenter, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Menu, PanelLeftClose, PanelLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCalendarStore } from '../store/calendarStore';
import { useDragEvents } from '../hooks/useDragEvents';
import { useKeyboardShortcuts } from '../hooks/useKeyboardShortcuts';
import { useDailyPlanner } from '../hooks/useDailyPlanner';
import { useNLPInput } from '../hooks/useNLPInput';
import { TopBar } from '../components/TopBar';
import { MiniCalendar } from '../components/MiniCalendar';
import { SidebarCalendarsList } from '../components/SidebarCalendarsList';
import { MonthView } from '../components/MonthView';
import { WeekView } from '../components/WeekView';
import { DayView } from '../components/DayView';
import { AgendaView } from '../components/AgendaView';
import { EventPopover } from '../components/EventPopover';
import { CreateEventModal } from '../components/CreateEventModal';
import { AIPanel } from '../components/AIPanel';
import { AIConsentModal } from '../components/AIConsentModal';
import { UndoToastContainer } from '../components/UndoToast';
import { DragLayer } from '../components/DragLayer';

export function CalendarPage() {
  const { 
    currentView, 
    isSidebarOpen, 
    setIsSidebarOpen,
    isAIPanelOpen,
  } = useCalendarStore();

  const {
    handleDragStart,
    handleDragMove,
    handleDragEnd,
    handleDragCancel,
  } = useDragEvents();

  const { handlePlanMyDay, isLoading: isPlanningDay } = useDailyPlanner();
  const { focusInput } = useNLPInput();

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  useKeyboardShortcuts({
    onOpenNLInput: focusInput,
  });

  const handleSidebarToggle = useCallback(() => {
    setIsSidebarOpen(!isSidebarOpen);
  }, [isSidebarOpen, setIsSidebarOpen]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, [setIsSidebarOpen]);

  const renderCalendarView = () => {
    switch (currentView) {
      case 'month':
        return <MonthView />;
      case 'week':
        return <WeekView />;
      case 'day':
        return <DayView />;
      case 'agenda':
        return <AgendaView />;
      default:
        return <WeekView />;
    }
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragMove={handleDragMove}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <div className="h-screen flex flex-col bg-background" data-testid="calendar-page">
        <TopBar />

        <div className="flex-1 flex overflow-hidden">
          <AnimatePresence initial={false}>
            {isSidebarOpen && (
              <motion.aside
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 280, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="h-full border-r bg-sidebar flex flex-col overflow-hidden"
                role="complementary"
                aria-label="Calendar sidebar"
                data-testid="calendar-sidebar"
              >
                <div className="flex items-center justify-between p-2 border-b">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleSidebarToggle}
                    aria-label="Close sidebar"
                    data-testid="button-close-sidebar"
                  >
                    <PanelLeftClose className="h-4 w-4" />
                  </Button>
                  <Button
                    onClick={handlePlanMyDay}
                    disabled={isPlanningDay}
                    size="sm"
                    className="gap-2"
                    aria-label="Plan my day with AI"
                    data-testid="button-plan-my-day"
                  >
                    {isPlanningDay ? (
                      <div className="h-4 w-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                    Plan my day
                  </Button>
                </div>

                <div className="flex-1 overflow-y-auto">
                  <MiniCalendar />
                  <div className="border-t">
                    <SidebarCalendarsList />
                  </div>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {!isSidebarOpen && (
            <div className="absolute top-[68px] left-2 z-10">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSidebarToggle}
                aria-label="Open sidebar"
                data-testid="button-open-sidebar"
              >
                <PanelLeft className="h-4 w-4" />
              </Button>
            </div>
          )}

          <main 
            className="flex-1 overflow-hidden relative"
            role="main"
            aria-label="Calendar view"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={currentView}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="h-full"
              >
                {renderCalendarView()}
              </motion.div>
            </AnimatePresence>
          </main>

          <AIPanel />
        </div>

        <EventPopover />
        <CreateEventModal />
        <AIConsentModal />
        <UndoToastContainer />
        <DragLayer />
      </div>
    </DndContext>
  );
}
